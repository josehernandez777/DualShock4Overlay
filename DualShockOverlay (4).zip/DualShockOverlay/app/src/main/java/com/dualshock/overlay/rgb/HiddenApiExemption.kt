package com.dualshock.overlay.rgb

import android.os.Build
import java.lang.reflect.Method

/**
 * Android 9+ bloquea el acceso por reflexión a APIs internas. En Android 9/10 existe un fallo conocido
 * ("meta-reflexión"): si es el propio sistema quien invoca getDeclaredMethod, la comprobación se salta
 * y se puede pedir a ART una exención. Es frágil: Google lo cerró en versiones posteriores, así que solo
 * se intenta aquí (Android 10 del Note 9) y el resultado se muestra tal cual en el diagnóstico.
 */
object HiddenApiExemption {
    @Volatile var status = "no intentado"
    private var done = false

    @Synchronized fun exemptAll(): Boolean {
        if (done) return status.startsWith("aplicada")
        done = true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status = "aplicada: no necesaria (Android < 9)"; return true }
        return try {
            val forName = Class::class.java.getDeclaredMethod("forName", String::class.java)
            val getDeclared = Class::class.java.getDeclaredMethod(
                "getDeclaredMethod", String::class.java, arrayOf<Class<*>>().javaClass
            )
            val vmRuntimeClass = forName.invoke(null, "dalvik.system.VMRuntime") as Class<*>
            val getRuntime = getDeclared.invoke(vmRuntimeClass, "getRuntime", null) as Method
            val setExemptions = getDeclared.invoke(
                vmRuntimeClass, "setHiddenApiExemptions", arrayOf(arrayOf<String>().javaClass)
            ) as Method
            val vm = getRuntime.invoke(null)
            setExemptions.invoke(vm, arrayOf("L"))
            status = "aplicada (Android ${Build.VERSION.SDK_INT})"
            true
        } catch (e: Throwable) {
            status = "FALLÓ: ${e.javaClass.simpleName} ${e.message ?: ""}".trim()
            false
        }
    }
}
