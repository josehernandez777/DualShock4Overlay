package com.dualshock.overlay.rgb

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.lang.reflect.InvocationTargetException

/**
 * Android NO ofrece API pública para escribir informes de salida a un mando HID Bluetooth
 * (BluetoothHidDevice es solo el rol "dispositivo"). La única vía sin root es el perfil
 * HID Host interno (BluetoothInputDevice en Android 10 / BluetoothHidHost en 11+), mediante
 * reflexión sobre APIs ocultas. Android o Samsung pueden bloquearlas: por eso cada envío
 * devuelve un resultado explícito y nunca se asume que el LED cambió.
 */
class HidHostTransport(private val ctx: Context) {

    enum class Method(val label: String) {
        SEND_DATA("A · sendData"),
        SET_REPORT("B · setReport")
    }

    data class Result(val ok: Boolean, val detail: String)

    companion object { private const val PROFILE_INPUT_DEVICE = 4 }

    @Volatile var proxy: BluetoothProfile? = null
    @Volatile var proxyStatus = "sin iniciar"
    var onChange: (() -> Unit)? = null

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, p: BluetoothProfile) {
            proxy = p
            proxyStatus = "perfil HID Host conectado (${p.javaClass.simpleName})"
            onChange?.invoke()
        }
        override fun onServiceDisconnected(profile: Int) {
            proxy = null
            proxyStatus = "perfil HID Host desconectado"
            onChange?.invoke()
        }
    }

    fun open() {
        val ad = BluetoothAdapter.getDefaultAdapter()
        if (ad == null) { proxyStatus = "este dispositivo no tiene Bluetooth"; return }
        val ok = try {
            ad.getProfileProxy(ctx, listener, PROFILE_INPUT_DEVICE)
        } catch (e: Exception) {
            proxyStatus = "getProfileProxy falló: ${e.javaClass.simpleName}"; false
        }
        if (!ok && proxy == null && proxyStatus == "sin iniciar")
            proxyStatus = "Android no abrió el perfil HID Host"
    }

    /** Comprueba si Android deja ver los métodos ocultos (sin enviar nada). */
    fun probe(): Pair<Boolean?, String> {
        val p = proxy ?: return Pair(null, "perfil HID Host aún no disponible")
        fun has(name: String, vararg t: Class<*>): Boolean =
            try { p.javaClass.getMethod(name, *t); true } catch (e: Exception) { false }
        val a = has("sendData", BluetoothDevice::class.java, String::class.java)
        val b = has("setReport", BluetoothDevice::class.java, java.lang.Byte.TYPE, String::class.java)
        val visible = try {
            p.javaClass.declaredMethods.map { it.name }
                .filter { it.contains("report", true) || it.contains("data", true) }.distinct().sorted()
        } catch (e: Throwable) { emptyList() }
        val txt = "clase: ${p.javaClass.name}\nsendData: ${if (a) "accesible" else "BLOQUEADO"}\n" +
            "setReport: ${if (b) "accesible" else "BLOQUEADO"}\n" +
            "métodos visibles (report/data): ${if (visible.isEmpty()) "ninguno" else visible.joinToString()}"
        return Pair(a || b, txt)
    }

    fun send(dev: BluetoothDevice, report: ByteArray, method: Method): Result {
        val p = proxy ?: return Result(false, "Perfil HID Host no disponible ($proxyStatus)")
        val hex = report.joinToString("") { "%02x".format(it) }
        return try {
            val accepted: Boolean = when (method) {
                Method.SEND_DATA ->
                    p.javaClass.getMethod("sendData", BluetoothDevice::class.java, String::class.java)
                        .invoke(p, dev, hex) as Boolean
                Method.SET_REPORT ->
                    p.javaClass.getMethod("setReport", BluetoothDevice::class.java, java.lang.Byte.TYPE, String::class.java)
                        .invoke(p, dev, 2.toByte(), hex) as Boolean
            }
            if (accepted) Result(true, "Android aceptó el envío (${method.label}). Esto NO confirma que el LED cambió.")
            else Result(false, "Android rechazó el envío (${method.label} devolvió false)")
        } catch (e: NoSuchMethodException) {
            Result(false, "API oculta no accesible (${method.label}): bloqueada por Android o inexistente")
        } catch (e: InvocationTargetException) {
            val c = e.targetException
            Result(false, "${method.label} lanzó ${c?.javaClass?.simpleName}: ${c?.message}")
        } catch (e: Exception) {
            Result(false, "${e.javaClass.simpleName}: ${e.message}")
        }
    }
}
