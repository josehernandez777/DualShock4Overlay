package com.dualshock.overlay.rgb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.*
import com.dualshock.overlay.R

class LightbarActivity : Activity() {

    private lateinit var ledBar: LedBarView
    private lateinit var picker: ColorPickerView
    private lateinit var etHex: EditText
    private lateinit var sb: List<SeekBar>
    private lateinit var tvRgb: List<TextView>
    private lateinit var fx: List<Button>
    private lateinit var mBtn: List<Button>
    private var updatingHex = false
    private val listener: () -> Unit = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lightbar)
        LightbarEngine.load(this)

        ledBar = findViewById(R.id.ledBar)
        picker = findViewById(R.id.picker)
        etHex = findViewById(R.id.etHex)
        sb = listOf<SeekBar>(findViewById(R.id.sbR), findViewById(R.id.sbG), findViewById(R.id.sbB))
        tvRgb = listOf<TextView>(findViewById(R.id.tvR), findViewById(R.id.tvG), findViewById(R.id.tvB))
        fx = listOf(R.id.fx0, R.id.fx1, R.id.fx2, R.id.fx3, R.id.fx4).map { findViewById<Button>(it) }
        mBtn = listOf(R.id.mA, R.id.mB).map { findViewById<Button>(it) }

        picker.onChange = { setColor(it, picker) }
        sb.forEach { s ->
            s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(x: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) setColor(Color.rgb(sb[0].progress, sb[1].progress, sb[2].progress), s)
                }
                override fun onStartTrackingTouch(x: SeekBar) {}
                override fun onStopTrackingTouch(x: SeekBar) {}
            })
        }
        etHex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updatingHex) return
                val t = s.toString().trim().removePrefix("#")
                if (t.length == 6) try { setColor(Color.parseColor("#$t"), etHex) } catch (_: Exception) {}
            }
        })

        Effect.values().forEachIndexed { i, e ->
            fx[i].text = e.label
            fx[i].setOnClickListener { selectEffect(e) }
        }
        val speed = findViewById<SeekBar>(R.id.sbSpeed)
        speed.progress = LightbarEngine.speed - 1
        speed.setOnSeekBarChangeListener(simple { LightbarEngine.speed = it + 1; findViewById<TextView>(R.id.tvSpeed).text = "Velocidad  ${it + 1}%" })
        findViewById<TextView>(R.id.tvSpeed).text = "Velocidad  ${LightbarEngine.speed}%"

        val sbOn = findViewById<SeekBar>(R.id.sbOn); val sbOff = findViewById<SeekBar>(R.id.sbOff)
        sbOn.progress = LightbarEngine.flashOn; sbOff.progress = LightbarEngine.flashOff
        sbOn.setOnSeekBarChangeListener(simple { LightbarEngine.flashOn = it; flashLabels() })
        sbOff.setOnSeekBarChangeListener(simple { LightbarEngine.flashOff = it; flashLabels() })
        flashLabels()

        findViewById<Button>(R.id.btnApply).setOnClickListener {
            startForegroundService(Intent(this, LightbarService::class.java))
            LightbarEngine.apply(this)
            LightbarEngine.save(this)
        }
        findViewById<Button>(R.id.btnDefault).setOnClickListener {
            LightbarEngine.restoreDefault(this)
            startService(Intent(this, LightbarService::class.java).setAction(LightbarService.ACTION_STOP))
            selectEffect(Effect.STATIC)
            setColor(LightbarEngine.baseColor, null)
            LightbarEngine.save(this)
        }
        mBtn[0].setOnClickListener { setMethod(HidHostTransport.Method.SEND_DATA) }
        mBtn[1].setOnClickListener { setMethod(HidHostTransport.Method.SET_REPORT) }
        findViewById<Button>(R.id.btnYes).setOnClickListener { LightbarEngine.verified = true; refresh() }
        findViewById<Button>(R.id.btnNo).setOnClickListener { LightbarEngine.verified = false; refresh() }

        setColor(LightbarEngine.baseColor, null)
        selectEffect(LightbarEngine.effect)
        setMethod(LightbarEngine.method)
    }

    private fun simple(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    private fun flashLabels() {
        findViewById<TextView>(R.id.tvOn).text = "Encendido  ${LightbarEngine.flashOn * 10} ms"
        findViewById<TextView>(R.id.tvOff).text = "Apagado  ${LightbarEngine.flashOff * 10} ms"
    }

    private fun setColor(c: Int, source: View?) {
        val col = c or 0xFF000000.toInt()
        LightbarEngine.baseColor = col
        if (source !== picker) picker.setColor(col)
        if (source !== etHex) {
            updatingHex = true
            etHex.setText(String.format("%02X%02X%02X", Color.red(col), Color.green(col), Color.blue(col)))
            updatingHex = false
        }
        val v = intArrayOf(Color.red(col), Color.green(col), Color.blue(col))
        val n = arrayOf("R", "G", "B")
        for (i in 0..2) {
            if (source !== sb[i]) sb[i].progress = v[i]
            tvRgb[i].text = "${n[i]}  ${v[i]}"
        }
        ledBar.invalidate()
    }

    private fun selectEffect(e: Effect) {
        LightbarEngine.effect = e
        fx.forEachIndexed { i, b -> style(b, Effect.values()[i] == e) }
        findViewById<View>(R.id.flashBox).visibility = if (e == Effect.CUSTOM) View.VISIBLE else View.GONE
        findViewById<View>(R.id.speedBox).visibility = if (LightbarEngine.isAnimated()) View.VISIBLE else View.GONE
        ledBar.invalidate()
    }

    private fun setMethod(m: HidHostTransport.Method) {
        LightbarEngine.method = m
        mBtn[0].text = HidHostTransport.Method.SEND_DATA.label
        mBtn[1].text = HidHostTransport.Method.SET_REPORT.label
        style(mBtn[0], m == HidHostTransport.Method.SEND_DATA)
        style(mBtn[1], m == HidHostTransport.Method.SET_REPORT)
        LightbarEngine.save(this)
    }

    private fun style(b: Button, on: Boolean) {
        b.setBackgroundResource(if (on) R.drawable.btn_primary else R.drawable.btn_secondary)
        b.setTextColor(if (on) 0xFF06202B.toInt() else 0xFFE6EDF3.toInt())
    }

    private fun chip(id: Int, ok: Boolean?, text: String) {
        val sb = SpannableStringBuilder("●  $text")
        val c = when (ok) { true -> 0xFF4CD97B; false -> 0xFFFF6B6B; null -> 0xFF8B97A6 }.toInt()
        sb.setSpan(ForegroundColorSpan(c), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        findViewById<TextView>(id).text = sb
    }

    private fun refresh() {
        val e = LightbarEngine
        chip(R.id.chipDev, if (e.connected) true else false, e.deviceText())
        val hid = e.hidText()
        chip(R.id.chipHid, hid.first, hid.second)
        chip(R.id.chipSend, e.lastOk, e.lastResult)
        val showVerify = e.applied && e.lastOk == true
        findViewById<View>(R.id.verifyBox).visibility = if (showVerify) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tvVerify).text = when (e.verified) {
            true -> "Confirmado por ti: el LED físico cambió."
            false -> "Marcado como NO cambió. Prueba el método B o revisa el diagnóstico."
            null -> "¿Cambió el color del LED físico del mando?"
        }
        findViewById<TextView>(R.id.tvDiag).text = e.diagText()
    }

    override fun onResume() {
        super.onResume()
        LightbarEngine.ensureStarted(this)
        LightbarEngine.addListener(listener)
        refresh()
    }

    override fun onPause() {
        LightbarEngine.removeListener(listener)
        super.onPause()
    }
}
