package com.dualshock.overlay.rgb

import java.util.zip.CRC32

/**
 * Informe de salida Bluetooth 0x11 del DualShock 4 (78 bytes), según hid-sony / hid-playstation:
 *  [0]=0x11  [1]=0xC0|poll (HID+CRC)  [3]=flags (0x01 motores, 0x02 lightbar, 0x04 parpadeo)
 *  [8..10]=R,G,B  [11]=parpadeo ON  [12]=parpadeo OFF (unidades de 10 ms)
 *  [74..77]=CRC32 little-endian calculado sobre 0xA2 + los primeros 74 bytes.
 * CUH-ZCT1 (PID 0x05C4) y CUH-ZCT2 (PID 0x09CC) usan el mismo informe.
 */
object Ds4Protocol {
    const val VID_SONY = 0x054c
    const val PID_ZCT1 = 0x05c4
    const val PID_ZCT2 = 0x09cc
    const val PID_DONGLE = 0x0ba0

    const val DEFAULT_R = 0
    const val DEFAULT_G = 0
    const val DEFAULT_B = 64   // azul "jugador 1" que usa el kernel

    fun modelName(pid: Int) = when (pid) {
        PID_ZCT1 -> "CUH-ZCT1"
        PID_ZCT2 -> "CUH-ZCT2"
        PID_DONGLE -> "Adaptador DS4"
        else -> "DS4 (PID 0x%04x)".format(pid)
    }

    fun btLightbarReport(r: Int, g: Int, b: Int, flashOn: Int = 0, flashOff: Int = 0): ByteArray {
        val buf = ByteArray(78)
        buf[0] = 0x11
        buf[1] = (0xC0 or 4).toByte()
        buf[3] = 0x06                       // solo lightbar + parpadeo: no toca la vibración
        buf[8] = r.toByte(); buf[9] = g.toByte(); buf[10] = b.toByte()
        buf[11] = flashOn.toByte(); buf[12] = flashOff.toByte()
        val crc = CRC32()
        crc.update(0xA2)
        crc.update(buf, 0, 74)
        val v = crc.value
        buf[74] = (v and 0xFF).toByte()
        buf[75] = ((v shr 8) and 0xFF).toByte()
        buf[76] = ((v shr 16) and 0xFF).toByte()
        buf[77] = ((v shr 24) and 0xFF).toByte()
        return buf
    }
}
