package com.dualshock.overlay.rgb

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import com.dualshock.overlay.GamepadRepo

object Ds4Finder {
    fun isDs4(d: BluetoothDevice): Boolean {
        val n = try { d.name } catch (e: SecurityException) { null } ?: return false
        return n.contains("Wireless Controller", true) || n.contains("DUALSHOCK", true)
    }

    fun bonded(): List<BluetoothDevice> = try {
        BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.filter { isDs4(it) } ?: emptyList()
    } catch (e: SecurityException) { emptyList() }

    /** Modelo según el PID que Android ve en el InputDevice (solo si está conectado). */
    fun modelFromInput(): String? =
        GamepadRepo.connectedPads().firstOrNull { it.vendorId == Ds4Protocol.VID_SONY }
            ?.let { Ds4Protocol.modelName(it.productId) }
}
