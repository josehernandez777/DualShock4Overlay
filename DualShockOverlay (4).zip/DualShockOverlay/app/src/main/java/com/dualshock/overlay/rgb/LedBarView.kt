package com.dualshock.overlay.rgb

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View

/** Barra LED virtual: SOLO vista previa en pantalla, no refleja el estado real del mando. */
class LedBarView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var blur: BlurMaskFilter? = null

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        blur = BlurMaskFilter(h * 0.32f, BlurMaskFilter.Blur.NORMAL)
    }

    override fun onDraw(cv: Canvas) {
        val col = LightbarEngine.colorAt(SystemClock.elapsedRealtime())
        val w = width.toFloat(); val h = height.toFloat()
        val barH = h * 0.32f; val padX = w * 0.06f
        rect.set(padX, (h - barH) / 2, w - padX, (h + barH) / 2)
        p.style = Paint.Style.FILL
        p.maskFilter = blur; p.color = col; p.alpha = 170
        cv.drawRoundRect(rect, barH / 2, barH / 2, p)
        p.maskFilter = null; p.color = col
        cv.drawRoundRect(rect, barH / 2, barH / 2, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x44FFFFFF
        cv.drawRoundRect(rect, barH / 2, barH / 2, p)
        if (LightbarEngine.isAnimated()) postInvalidateOnAnimation()
    }
}
