package com.dualshock.overlay.rgb

import android.app.*
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dualshock.overlay.MainActivity
import com.dualshock.overlay.R

/**
 * Mantiene vivos los efectos y detecta conexión/desconexión del DS4 para reaplicar el color.
 * Solo hace trabajo mientras hay un color/efecto aplicado.
 */
class LightbarService : Service() {
    companion object {
        const val ACTION_STOP = "com.dualshock.overlay.LED_STOP"
        private const val CH = "lightbar"
        private const val ID = 2
        @Volatile var running = false
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
            if (!Ds4Finder.isDs4(d)) return
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> LightbarEngine.onControllerConnected()
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> LightbarEngine.onControllerDisconnected()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Barra LED", NotificationManager.IMPORTANCE_LOW))
        registerReceiver(rx, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(ID, notification())
        if (intent?.action == ACTION_STOP) {
            LightbarEngine.stopAll()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        LightbarEngine.ensureStarted(this)
        return START_STICKY
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, LightbarActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getForegroundService(
            this, 9, Intent(this, LightbarService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Barra LED del DS4")
            .setContentText("Efecto: ${LightbarEngine.effect.label}")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(0, "Detener", stop)
            .build()
    }

    override fun onDestroy() {
        try { unregisterReceiver(rx) } catch (_: Exception) {}
        running = false
        super.onDestroy()
    }
}
