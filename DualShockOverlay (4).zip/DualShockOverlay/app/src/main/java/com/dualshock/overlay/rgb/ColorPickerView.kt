package com.dualshock.overlay.rgb

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** Selector HSV: cuadrado saturación/brillo + barra de tono. */
class ColorPickerView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val svRect = RectF()
    private val hueRect = RectF()
    private var hue = 200f; private var sat = 1f; private var value = 1f
    private var svShader: Shader? = null
    private var shaderHue = -1f
    private var hueShader: Shader? = null
    private var dragSv = false; private var dragHue = false
    var onChange: ((Int) -> Unit)? = null

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setColor(color: Int) {
        val hsv = FloatArray(3); Color.colorToHSV(color, hsv)
        if (hsv[1] > 0.01f && hsv[2] > 0.01f) hue = hsv[0]
        sat = hsv[1]; value = hsv[2]
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val hueH = dp(28f); val gap = dp(14f)
        svRect.set(0f, 0f, w.toFloat(), h - hueH - gap)
        hueRect.set(0f, h - hueH, w.toFloat(), h.toFloat())
        val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        hueShader = LinearGradient(0f, 0f, w.toFloat(), 0f, cols, null, Shader.TileMode.CLAMP)
        shaderHue = -1f
    }

    override fun onDraw(cv: Canvas) {
        if (shaderHue != hue) {
            val pure = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
            val h1 = LinearGradient(svRect.left, 0f, svRect.right, 0f, Color.WHITE, pure, Shader.TileMode.CLAMP)
            val h2 = LinearGradient(0f, svRect.top, 0f, svRect.bottom, 0x00000000, Color.BLACK, Shader.TileMode.CLAMP)
            svShader = ComposeShader(h1, h2, PorterDuff.Mode.SRC_OVER)
            shaderHue = hue
        }
        val r = dp(12f)
        p.style = Paint.Style.FILL; p.shader = svShader
        cv.drawRoundRect(svRect, r, r, p)
        p.shader = hueShader
        cv.drawRoundRect(hueRect, hueRect.height() / 2, hueRect.height() / 2, p)
        p.shader = null

        // marcador SV
        val mx = sat * svRect.width(); val my = (1f - value) * svRect.height()
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(3f); p.color = Color.WHITE
        cv.drawCircle(mx, my, dp(11f), p)
        p.strokeWidth = dp(1.5f); p.color = 0x99000000.toInt()
        cv.drawCircle(mx, my, dp(13f), p)
        // marcador tono
        val hx = hue / 360f * hueRect.width()
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        cv.drawCircle(hx.coerceIn(hueRect.height() / 2, hueRect.width() - hueRect.height() / 2), hueRect.centerY(), hueRect.height() / 2 - dp(2f), p)
        p.style = Paint.Style.FILL
        p.color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        cv.drawCircle(hx.coerceIn(hueRect.height() / 2, hueRect.width() - hueRect.height() / 2), hueRect.centerY(), hueRect.height() / 2 - dp(6f), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            dragSv = svRect.contains(e.x, e.y)
            dragHue = !dragSv && e.y >= hueRect.top - dp(10f)
        }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            val was = dragSv || dragHue
            dragSv = false; dragHue = false
            return was
        }
        when {
            dragSv -> {
                sat = (e.x / svRect.width()).coerceIn(0f, 1f)
                value = 1f - (e.y / svRect.height()).coerceIn(0f, 1f)
            }
            dragHue -> hue = (e.x / hueRect.width() * 360f).coerceIn(0f, 359.9f)
            else -> return false
        }
        invalidate()
        onChange?.invoke(Color.HSVToColor(floatArrayOf(hue, sat, value)))
        return true
    }
}
