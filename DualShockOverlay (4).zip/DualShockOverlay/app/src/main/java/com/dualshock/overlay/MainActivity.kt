package com.dualshock.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var debug: TextView
    private lateinit var tvOpacity: TextView
    private lateinit var tvSize: TextView
    private val listener: () -> Unit = { debug.text = GamepadRepo.lastInfo }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        debug = findViewById(R.id.debug)
        tvOpacity = findViewById(R.id.tvOpacity)
        tvSize = findViewById(R.id.tvSize)

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        findViewById<Button>(R.id.btnPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Falta el permiso de superposición", Toast.LENGTH_LONG).show()
            } else {
                Prefs.sp(this).edit().putBoolean(Prefs.K_VISIBLE, true).apply()
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START))
            }
            refresh()
        }
        findViewById<Button>(R.id.btnToggle).setOnClickListener {
            if (OverlayService.running)
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_TOGGLE))
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            refresh()
        }

        findViewById<Button>(R.id.btnRgb).setOnClickListener {
            startActivity(Intent(this, com.dualshock.overlay.rgb.LightbarActivity::class.java))
        }

        val sw = findViewById<Switch>(R.id.swLock)
        sw.isChecked = Prefs.locked(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.sp(this).edit().putBoolean(Prefs.K_LOCKED, on).apply() }

        val sbO = findViewById<SeekBar>(R.id.sbOpacity)
        sbO.progress = Prefs.opacity(this) - 20
        tvOpacity.text = "Opacidad  ${Prefs.opacity(this)}%"
        sbO.setOnSeekBarChangeListener(seek {
            Prefs.sp(this).edit().putInt(Prefs.K_OPACITY, it + 20).apply()
            tvOpacity.text = "Opacidad  ${it + 20}%"
        })

        val sbS = findViewById<SeekBar>(R.id.sbSize)
        sbS.progress = Prefs.scale(this) - 50
        tvSize.text = "Tamaño  ${Prefs.scale(this)}%"
        sbS.setOnSeekBarChangeListener(seek {
            Prefs.sp(this).edit().putInt(Prefs.K_SCALE, it + 50).apply()
            tvSize.text = "Tamaño  ${it + 50}%"
        })

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            Prefs.sp(this).edit().putInt(Prefs.K_SCALE, 100).putInt(Prefs.K_X, 40).putInt(Prefs.K_Y, 200).apply()
            sbS.progress = 50
            tvSize.text = "Tamaño  100%"
        }
    }

    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    override fun onResume() {
        super.onResume()
        GamepadRepo.addListener(listener)
        GamepadRepo.setAnalogLive(true)
        refresh()
    }

    override fun onPause() {
        GamepadRepo.setAnalogLive(false)
        GamepadRepo.removeListener(listener)
        super.onPause()
    }

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("GamepadAccessibilityService")
    }

    private fun chip(id: Int, ok: Boolean, text: String) {
        val sb = SpannableStringBuilder("●  $text")
        sb.setSpan(
            ForegroundColorSpan(if (ok) 0xFF4CD97B.toInt() else 0xFFFF6B6B.toInt()),
            0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        findViewById<TextView>(id).text = sb
    }

    private fun refresh() {
        val pads = GamepadRepo.connectedPads()
        val padTxt = if (pads.isEmpty()) "Mando: no detectado"
        else "Mando: " + pads.joinToString { it.name + if (GamepadRepo.isDualShock4(it)) " (DS4)" else "" }
        val perm = Settings.canDrawOverlays(this)
        val a11y = a11yEnabled()
        chip(R.id.chipPad, pads.isNotEmpty(), padTxt)
        chip(R.id.chipPerm, perm, if (perm) "Permiso de superposición: OK" else "Permiso de superposición: falta")
        chip(R.id.chipA11y, a11y, if (a11y) "Botones en segundo plano: activo" else "Botones en segundo plano: desactivado")
        chip(R.id.chipOverlay, OverlayService.running, if (OverlayService.running) "Overlay: en ejecución" else "Overlay: detenido")
        findViewById<View>(R.id.btnPerm).visibility = if (perm) View.GONE else View.VISIBLE
        findViewById<View>(R.id.btnA11y).visibility = if (a11y) View.GONE else View.VISIBLE
    }

    // Con la app en primer plano se reciben TODOS los ejes (sticks, gatillos, cruceta).
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        GamepadRepo.onKey(event)
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (GamepadRepo.isPadSource(ev.source)) {
            GamepadRepo.onMotion(ev)
            // Se consume SOLO dentro de esta pantalla: evita que Android convierta el stick
            // izquierdo en teclas DPAD falsas. No afecta a ningún juego.
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }
}
