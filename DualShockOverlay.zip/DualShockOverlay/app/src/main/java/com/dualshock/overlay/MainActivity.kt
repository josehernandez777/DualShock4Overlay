package com.dualshock.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var debug: TextView
    private val listener: () -> Unit = { debug.text = GamepadRepo.lastInfo }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        debug = findViewById(R.id.debug)

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        findViewById<Button>(R.id.btnPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Falta el permiso de superposición", Toast.LENGTH_LONG).show()
            } else {
                Prefs.sp(this).edit().putBoolean(Prefs.K_VISIBLE, true).apply()
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START))
            }
            refresh()
        }
        findViewById<Button>(R.id.btnToggle).setOnClickListener {
            if (OverlayService.running)
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_TOGGLE))
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            refresh()
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            Prefs.sp(this).edit().putInt(Prefs.K_SCALE, 100).putInt(Prefs.K_X, 40).putInt(Prefs.K_Y, 200).apply()
            findViewById<SeekBar>(R.id.sbSize).progress = 50
        }

        val sw = findViewById<Switch>(R.id.swLock)
        sw.isChecked = Prefs.locked(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.sp(this).edit().putBoolean(Prefs.K_LOCKED, on).apply() }

        val sbO = findViewById<SeekBar>(R.id.sbOpacity)
        sbO.progress = Prefs.opacity(this) - 20
        sbO.setOnSeekBarChangeListener(seek { Prefs.sp(this).edit().putInt(Prefs.K_OPACITY, it + 20).apply() })

        val sbS = findViewById<SeekBar>(R.id.sbSize)
        sbS.progress = Prefs.scale(this) - 50
        sbS.setOnSeekBarChangeListener(seek { Prefs.sp(this).edit().putInt(Prefs.K_SCALE, it + 50).apply() })
    }

    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    override fun onResume() {
        super.onResume()
        GamepadRepo.addListener(listener)
        refresh()
    }

    override fun onPause() {
        GamepadRepo.removeListener(listener)
        super.onPause()
    }

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("GamepadAccessibilityService")
    }

    private fun refresh() {
        val pads = GamepadRepo.connectedPads()
        val padTxt = if (pads.isEmpty()) "ninguno detectado"
        else pads.joinToString { it.name + if (GamepadRepo.isDualShock4(it)) " (DS4)" else "" }
        status.text = """
            Mando: $padTxt
            Permiso overlay: ${if (Settings.canDrawOverlays(this)) "OK" else "FALTA"}
            Botones en segundo plano (Accesibilidad): ${if (a11yEnabled()) "OK" else "desactivado"}
            Overlay: ${if (OverlayService.running) "en ejecución" else "detenido"}
            Sticks y cruceta en vivo: solo con esta app en primer plano (limitación de Android, ver README).
        """.trimIndent()
    }

    // Con la app en primer plano se reciben TODOS los ejes (sticks, gatillos, cruceta).
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        GamepadRepo.onKey(event)
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        GamepadRepo.onMotion(ev)
        return super.dispatchGenericMotionEvent(ev)
    }
}
