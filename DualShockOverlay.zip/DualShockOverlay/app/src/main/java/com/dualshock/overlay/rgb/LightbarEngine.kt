package com.dualshock.overlay.rgb

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import androidx.core.graphics.ColorUtils
import com.dualshock.overlay.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor

enum class Effect(val label: String) {
    STATIC("Static"), RAINBOW("Rainbow"), BREATHING("Breathing"), COLOR_CYCLE("Color Cycle"), CUSTOM("Custom")
}

object LightbarEngine {
    private val thread = HandlerThread("ds4-lightbar").also { it.start() }
    private val bg = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())
    private var transport: HidHostTransport? = null
    private var device: BluetoothDevice? = null
    private var loaded = false
    private val logBuf = java.util.ArrayDeque<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    @Volatile var effect = Effect.STATIC
    @Volatile var baseColor = Color.rgb(Ds4Protocol.DEFAULT_R, Ds4Protocol.DEFAULT_G, Ds4Protocol.DEFAULT_B)
    @Volatile var speed = 50
    @Volatile var flashOn = 0      // x10 ms (solo Custom, parpadeo por hardware)
    @Volatile var flashOff = 0
    @Volatile var method = HidHostTransport.Method.SEND_DATA
    @Volatile var applied = false
    @Volatile var connected = false
    @Volatile var lastOk: Boolean? = null
    @Volatile var lastResult = "Todavía no se ha enviado nada al mando."
    @Volatile var verified: Boolean? = null

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun changed() { main.post { listeners.forEach { it() } } }

    fun isAnimated() = effect == Effect.RAINBOW || effect == Effect.BREATHING || effect == Effect.COLOR_CYCLE

    // ---------- Persistencia ----------
    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val sp = Prefs.sp(ctx)
        baseColor = sp.getInt("rgb_color", baseColor)
        speed = sp.getInt("rgb_speed", 50)
        flashOn = sp.getInt("rgb_fon", 0); flashOff = sp.getInt("rgb_foff", 0)
        effect = try { Effect.valueOf(sp.getString("rgb_fx", "STATIC")!!) } catch (e: Exception) { Effect.STATIC }
        method = try { HidHostTransport.Method.valueOf(sp.getString("rgb_method", "SEND_DATA")!!) } catch (e: Exception) { HidHostTransport.Method.SEND_DATA }
    }

    fun save(ctx: Context) {
        Prefs.sp(ctx).edit().putInt("rgb_color", baseColor).putInt("rgb_speed", speed)
            .putInt("rgb_fon", flashOn).putInt("rgb_foff", flashOff)
            .putString("rgb_fx", effect.name).putString("rgb_method", method.name).apply()
    }

    // ---------- Ciclo de vida ----------
    @Synchronized fun ensureStarted(ctx: Context) {
        load(ctx)
        if (transport == null) {
            transport = HidHostTransport(ctx.applicationContext).also {
                it.onChange = { refreshConnection(); changed() }
                it.open()
            }
        }
        refreshConnection()
    }

    fun refreshConnection() {
        val bonded = Ds4Finder.bonded()
        val conn = try { transport?.proxy?.connectedDevices.orEmpty() } catch (e: Exception) { emptyList() }
        device = bonded.firstOrNull { it in conn } ?: bonded.firstOrNull()
        connected = device != null && device in conn
    }

    // ---------- Estado para la UI ----------
    fun deviceText(): String {
        val d = device ?: return "Ningún DS4 emparejado"
        val name = try { d.name } catch (e: SecurityException) { "DS4" }
        val model = Ds4Finder.modelFromInput()
        return "$name${if (model != null) " · $model" else ""} · ${if (connected) "conectado" else "no conectado"}"
    }

    @Volatile var lastProbe = ""

    fun hidText(): Pair<Boolean?, String> {
        val t = transport ?: return Pair(null, "HID Host: sin iniciar")
        val probe = t.probe()
        lastProbe = probe.second
        val txt = when (probe.first) {
            null -> "HID Host: ${t.proxyStatus}"
            true -> "HID Host: API oculta accesible"
            else -> "HID Host: API oculta BLOQUEADA"
        }
        return Pair(probe.first, txt)
    }

    fun diagText(): String = synchronized(logBuf) {
        "$lastProbe\n— registro —\n" + logBuf.joinToString("\n")
    }

    private fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        synchronized(logBuf) { logBuf.addLast("$t $msg"); while (logBuf.size > 12) logBuf.removeFirst() }
    }

    // ---------- Color ----------
    fun colorAt(t: Long): Int {
        val base = baseColor
        val s = speed.coerceIn(1, 100)
        return when (effect) {
            Effect.STATIC, Effect.CUSTOM -> base
            Effect.RAINBOW -> {
                val period = 12000f - (s - 1) * 105f
                val h = (t % period.toLong()) / period * 360f
                Color.HSVToColor(floatArrayOf(h, 1f, 1f))
            }
            Effect.BREATHING -> {
                val period = 6000f - (s - 1) * 45f
                val ph = (t % period.toLong()) / period
                val k = 0.04f + 0.96f * (0.5f - 0.5f * cos(2.0 * PI * ph).toFloat())
                Color.rgb((Color.red(base) * k).toInt(), (Color.green(base) * k).toInt(), (Color.blue(base) * k).toInt())
            }
            Effect.COLOR_CYCLE -> {
                val period = 18000f - (s - 1) * 150f
                val ph = (t % period.toLong()) / period * 3f
                val i = floor(ph).toInt() % 3
                val f = ph - floor(ph)
                val hsv = FloatArray(3); Color.colorToHSV(base, hsv)
                val sat = if (hsv[1] < 0.15f) 1f else hsv[1]
                val v = if (hsv[2] < 0.15f) 1f else hsv[2]
                val c0 = Color.HSVToColor(floatArrayOf((hsv[0] + i * 120f) % 360f, sat, v))
                val c1 = Color.HSVToColor(floatArrayOf((hsv[0] + (i + 1) * 120f) % 360f, sat, v))
                ColorUtils.blendARGB(c0, c1, f)
            }
        }
    }

    // ---------- Envío real ----------
    private fun sendColor(c: Int, on: Int, off: Int): Boolean {
        val dev = device
        if (dev == null) { record(false, "No hay ningún DS4 emparejado en Bluetooth"); return false }
        val rep = Ds4Protocol.btLightbarReport(Color.red(c), Color.green(c), Color.blue(c), on, off)
        val res = transport?.send(dev, rep, method) ?: HidHostTransport.Result(false, "Transporte no iniciado")
        record(res.ok, res.detail)
        return res.ok
    }

    private fun record(ok: Boolean, detail: String) {
        val changedState = lastOk != ok || lastResult != detail
        lastOk = ok; lastResult = detail
        if (changedState) { log((if (ok) "OK  " else "FALLO ") + detail); changed() }
    }

    private fun sendStatic() = sendColor(baseColor, if (effect == Effect.CUSTOM) flashOn else 0, if (effect == Effect.CUSTOM) flashOff else 0)

    private val tick = object : Runnable {
        override fun run() {
            if (!applied) return
            val ok = sendColor(colorAt(SystemClock.elapsedRealtime()), 0, 0)
            if (isAnimated()) bg.postDelayed(this, if (ok) 130L else 1500L)  // si falla, no insistir a 8 Hz
        }
    }

    fun apply(ctx: Context) {
        ensureStarted(ctx)
        applied = true; verified = null
        bg.removeCallbacks(tick)
        bg.post {
            refreshConnection()
            if (isAnimated()) tick.run() else sendStatic()
            changed()
        }
    }

    fun restoreDefault(ctx: Context) {
        ensureStarted(ctx)
        effect = Effect.STATIC; flashOn = 0; flashOff = 0
        baseColor = Color.rgb(Ds4Protocol.DEFAULT_R, Ds4Protocol.DEFAULT_G, Ds4Protocol.DEFAULT_B)
        verified = null
        bg.removeCallbacks(tick)
        bg.post { refreshConnection(); sendStatic(); applied = false; changed() }
    }

    fun stopAll() { applied = false; bg.removeCallbacks(tick); changed() }

    // ---------- Conexión / reconexión ----------
    fun onControllerConnected() {
        connected = true; log("Mando conectado"); changed()
        if (!applied) return
        // El mando vuelve con el color por defecto: se reaplica cuando el perfil HID esté listo.
        for (d in longArrayOf(1500, 3500, 7000)) bg.postDelayed({
            refreshConnection()
            if (applied) { bg.removeCallbacks(tick); if (isAnimated()) tick.run() else sendStatic() }
        }, d)
    }

    fun onControllerDisconnected() {
        connected = false; bg.removeCallbacks(tick); log("Mando desconectado"); changed()
    }
}
