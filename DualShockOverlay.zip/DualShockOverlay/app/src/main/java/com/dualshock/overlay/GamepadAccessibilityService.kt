package com.dualshock.overlay

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Único mecanismo sin root para ver los botones del mando mientras otra app tiene el foco.
 * Observa KeyEvents y devuelve false: NUNCA los consume, el juego los recibe igual.
 * No lee contenido de pantalla (canRetrieveWindowContent=false).
 */
class GamepadAccessibilityService : AccessibilityService() {
    override fun onKeyEvent(event: KeyEvent): Boolean {
        GamepadRepo.onKey(event)
        return false
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
