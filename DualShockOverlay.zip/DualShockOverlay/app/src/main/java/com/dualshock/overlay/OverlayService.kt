package com.dualshock.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val ACTION_START = "com.dualshock.overlay.START"
        const val ACTION_STOP = "com.dualshock.overlay.STOP"
        const val ACTION_TOGGLE = "com.dualshock.overlay.TOGGLE"
        const val ACTION_LOCK = "com.dualshock.overlay.LOCK"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        private const val BASE_W_DP = 320f
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private var view: GamepadView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var scaleDetector: ScaleGestureDetector
    private var startX = 0; private var startY = 0
    private var touchX = 0f; private var touchY = 0f
    private var pinchScale = 100f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        )
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val sp = Prefs.sp(this)
        when (intent?.action) {
            ACTION_STOP -> { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE -> sp.edit().putBoolean(Prefs.K_VISIBLE, !Prefs.visible(this)).apply()
            ACTION_LOCK -> sp.edit().putBoolean(Prefs.K_LOCKED, !Prefs.locked(this)).apply()
        }
        if (view == null) {
            if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
            createOverlay()
        }
        applyPrefs()
        return START_STICKY
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
    }

    private fun action(code: Int, label: String, act: String): NotificationCompat.Action {
        val pi = PendingIntent.getForegroundService(
            this, code, Intent(this, OverlayService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Action(0, label, pi)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val vis = Prefs.visible(this); val lock = Prefs.locked(this)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(if (vis) "Overlay visible" else "Overlay oculto")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(action(1, if (vis) "Ocultar" else "Mostrar", ACTION_TOGGLE))
            .addAction(action(2, if (lock) "Desbloquear" else "Bloquear", ACTION_LOCK))
            .addAction(action(3, "Cerrar", ACTION_STOP))
            .build()
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun windowFlags(): Int {
        // NOT_FOCUSABLE: jamás roba el foco ni las entradas del mando al juego.
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        // Bloqueado: el toque atraviesa el overlay hacia el juego.
        if (Prefs.locked(this)) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun createOverlay() {
        val v = GamepadView(this)
        val w = dp(BASE_W_DP * Prefs.scale(this) / 100f).toInt()
        lp = WindowManager.LayoutParams(
            w, (w * 0.62f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            windowFlags(), PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.x(this@OverlayService); y = Prefs.y(this@OverlayService) }

        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                pinchScale = (pinchScale * d.scaleFactor).coerceIn(50f, 200f)
                Prefs.sp(this@OverlayService).edit().putInt(Prefs.K_SCALE, pinchScale.toInt()).apply()
                return true
            }
        })
        v.setOnTouchListener { _, e -> onOverlayTouch(e); true }
        view = v
        wm.addView(v, lp)
    }

    private fun onOverlayTouch(e: MotionEvent) {
        pinchScale = Prefs.scale(this).toFloat()
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
            }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                lp.x = startX + (e.rawX - touchX).toInt()
                lp.y = startY + (e.rawY - touchY).toInt()
                view?.let { wm.updateViewLayout(it, lp) }
            }
            MotionEvent.ACTION_UP -> Prefs.sp(this).edit().putInt(Prefs.K_X, lp.x).putInt(Prefs.K_Y, lp.y).apply()
        }
    }

    private fun applyPrefs() {
        val v = view ?: return
        v.alpha = Prefs.opacity(this) / 100f
        v.visibility = if (Prefs.visible(this)) View.VISIBLE else View.GONE
        lp.width = dp(BASE_W_DP * Prefs.scale(this) / 100f).toInt()
        lp.height = (lp.width * 0.62f).toInt()
        lp.flags = windowFlags()
        if (Prefs.sp(this).contains(Prefs.K_X) && !v.isPressed) { /* posición se actualiza al arrastrar */ }
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (view == null) return
        if (key == Prefs.K_X || key == Prefs.K_Y) {
            // Reset desde la app
            lp.x = Prefs.x(this); lp.y = Prefs.y(this)
        }
        applyPrefs()
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
        running = false
        super.onDestroy()
    }
}
