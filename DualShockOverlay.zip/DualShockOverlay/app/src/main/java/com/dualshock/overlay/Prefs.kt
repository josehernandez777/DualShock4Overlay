package com.dualshock.overlay

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val K_OPACITY = "opacity"   // 20..100
    const val K_SCALE = "scale"       // 50..200
    const val K_X = "x"
    const val K_Y = "y"
    const val K_LOCKED = "locked"
    const val K_VISIBLE = "visible"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("overlay", Context.MODE_PRIVATE)

    fun opacity(c: Context) = sp(c).getInt(K_OPACITY, 85)
    fun scale(c: Context) = sp(c).getInt(K_SCALE, 100)
    fun x(c: Context) = sp(c).getInt(K_X, 40)
    fun y(c: Context) = sp(c).getInt(K_Y, 200)
    fun locked(c: Context) = sp(c).getBoolean(K_LOCKED, false)
    fun visible(c: Context) = sp(c).getBoolean(K_VISIBLE, true)
}
