package com.dualshock.overlay

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        GamepadRepo.init(this)
    }
}
