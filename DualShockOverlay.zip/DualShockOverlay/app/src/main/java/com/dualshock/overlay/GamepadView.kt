package com.dualshock.overlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import kotlin.math.abs

/** Dibuja el DualShock 4 en un espacio virtual de 1000x620. */
class GamepadView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()
    private val listener: () -> Unit = { invalidate() }

    private val IDLE = 0xFF3A3F48.toInt()
    private val BODY = 0xFF23272E.toInt()
    private val EDGE = 0xFF565C68.toInt()
    private val LIGHT = 0xFFFFFFFF.toInt()
    private val CYAN = 0xFF4FC3F7.toInt()
    private val CROSS = 0xFF5C8DFF.toInt()
    private val CIRCLE = 0xFFFF5252.toInt()
    private val SQUARE = 0xFFFF80C0.toInt()
    private val TRI = 0xFF4CD97B.toInt()

    override fun onAttachedToWindow() { super.onAttachedToWindow(); GamepadRepo.addListener(listener) }
    override fun onDetachedFromWindow() { GamepadRepo.removeListener(listener); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w).let { if (it <= 0) 800 else it }
        setMeasuredDimension(width, (width * 0.62f).toInt())
    }

    private fun down(k: Int) = GamepadRepo.pressed.contains(k)

    override fun onDraw(cv: Canvas) {
        cv.save()
        cv.scale(width / 1000f, height / 620f)
        val s = GamepadRepo

        // Cuerpo
        shape(cv, 60f, 200f, 300f, 600f, 110f, false, BODY)
        shape(cv, 700f, 200f, 940f, 600f, 110f, false, BODY)
        shape(cv, 150f, 150f, 850f, 470f, 120f, false, BODY)
        shape(cv, 380f, 175f, 620f, 290f, 18f, false, 0xFF1B1E24.toInt()) // touchpad

        // Gatillos analógicos L2/R2 (relleno proporcional) y hombros L1/R1
        val l2v = if (down(KeyEvent.KEYCODE_BUTTON_L2)) 1f else s.l2
        val r2v = if (down(KeyEvent.KEYCODE_BUTTON_R2)) 1f else s.r2
        trigger(cv, 130f, 280f, l2v, "L2")
        trigger(cv, 720f, 870f, r2v, "R2")
        bumper(cv, 110f, 300f, down(KeyEvent.KEYCODE_BUTTON_L1), "L1")
        bumper(cv, 700f, 890f, down(KeyEvent.KEYCODE_BUTTON_R1), "R1")

        // Share / Options
        small(cv, 330f, 165f, 360f, 210f, down(KeyEvent.KEYCODE_BUTTON_SELECT), "SHARE", 290f)
        small(cv, 640f, 165f, 670f, 210f, down(KeyEvent.KEYCODE_BUTTON_START), "OPTIONS", 710f)

        // Cruceta (HAT o DPAD_* según el firmware)
        val cx = 230f; val cy = 240f
        val up = s.hatY < -0.5f || down(KeyEvent.KEYCODE_DPAD_UP)
        val dn = s.hatY > 0.5f || down(KeyEvent.KEYCODE_DPAD_DOWN)
        val lf = s.hatX < -0.5f || down(KeyEvent.KEYCODE_DPAD_LEFT)
        val rt = s.hatX > 0.5f || down(KeyEvent.KEYCODE_DPAD_RIGHT)
        shape(cv, cx - 22, cy - 74, cx + 22, cy - 20, 8f, up, CYAN)
        shape(cv, cx - 22, cy + 20, cx + 22, cy + 74, 8f, dn, CYAN)
        shape(cv, cx - 74, cy - 22, cx - 20, cy + 22, 8f, lf, CYAN)
        shape(cv, cx + 20, cy - 22, cx + 74, cy + 22, 8f, rt, CYAN)

        // Botones de cara
        val fx = 770f; val fy = 240f
        face(cv, fx, fy - 70, down(KeyEvent.KEYCODE_BUTTON_Y), TRI, 3)
        face(cv, fx + 70, fy, down(KeyEvent.KEYCODE_BUTTON_B), CIRCLE, 1)
        face(cv, fx, fy + 70, down(KeyEvent.KEYCODE_BUTTON_A), CROSS, 0)
        face(cv, fx - 70, fy, down(KeyEvent.KEYCODE_BUTTON_X), SQUARE, 2)

        // PS
        p.style = Paint.Style.FILL
        p.color = if (down(KeyEvent.KEYCODE_BUTTON_MODE)) LIGHT else IDLE
        cv.drawCircle(500f, 380f, 22f, p)
        stroke(cv) { it.drawCircle(500f, 380f, 22f, p) }

        // Sticks
        stick(cv, 360f, 400f, s.lx, s.ly, down(KeyEvent.KEYCODE_BUTTON_THUMBL))
        stick(cv, 640f, 400f, s.rx, s.ry, down(KeyEvent.KEYCODE_BUTTON_THUMBR))
        cv.restore()
    }

    private inline fun stroke(cv: Canvas, draw: (Canvas) -> Unit) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = EDGE
        draw(cv)
        p.style = Paint.Style.FILL
    }

    private fun shape(cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, lit: Boolean, color: Int) {
        rect.set(l, t, r, b)
        if (lit) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = (color and 0x00FFFFFF) or 0x66000000
            cv.drawRoundRect(rect, rad, rad, p)
        }
        p.style = Paint.Style.FILL
        p.color = if (lit) color else if (color == CYAN) IDLE else color
        cv.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = EDGE
        cv.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.FILL
    }

    private fun label(cv: Canvas, text: String, x: Float, y: Float, size: Float, color: Int) {
        tp.textSize = size; tp.color = color
        cv.drawText(text, x, y, tp)
    }

    private fun bumper(cv: Canvas, l: Float, r: Float, lit: Boolean, t: String) {
        shape(cv, l, 75f, r, 125f, 22f, lit, CYAN)
        label(cv, t, (l + r) / 2, 110f, 30f, if (lit) 0xFF111111.toInt() else 0xFFB0BEC5.toInt())
    }

    private fun trigger(cv: Canvas, l: Float, r: Float, v: Float, t: String) {
        val top = 8f; val bot = 62f
        shape(cv, l, top, r, bot, 14f, false, IDLE)
        if (v > 0.02f) {
            p.style = Paint.Style.FILL; p.color = CYAN
            rect.set(l + 3, bot - (bot - top - 6) * v.coerceIn(0f, 1f) - 3, r - 3, bot - 3)
            cv.drawRoundRect(rect, 10f, 10f, p)
        }
        label(cv, "$t ${(v * 100).toInt()}%", (l + r) / 2, 46f, 26f, 0xFFFFFFFF.toInt())
    }

    private fun small(cv: Canvas, l: Float, t: Float, r: Float, b: Float, lit: Boolean, txt: String, tx: Float) {
        shape(cv, l, t, r, b, 8f, lit, CYAN)
        label(cv, txt, tx, 140f, 17f, 0xFF90A4AE.toInt())
    }

    private fun face(cv: Canvas, x: Float, y: Float, lit: Boolean, color: Int, kind: Int) {
        if (lit) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = (color and 0x00FFFFFF) or 0x66000000
            cv.drawCircle(x, y, 34f, p)
        }
        p.style = Paint.Style.FILL; p.color = if (lit) color else IDLE
        cv.drawCircle(x, y, 34f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = EDGE
        cv.drawCircle(x, y, 34f, p)
        p.strokeWidth = 6f; p.color = if (lit) 0xFF111111.toInt() else color
        when (kind) {
            0 -> { cv.drawLine(x - 12, y - 12, x + 12, y + 12, p); cv.drawLine(x + 12, y - 12, x - 12, y + 12, p) }
            1 -> cv.drawCircle(x, y, 13f, p)
            2 -> { rect.set(x - 12, y - 12, x + 12, y + 12); cv.drawRect(rect, p) }
            else -> {
                path.reset(); path.moveTo(x, y - 15); path.lineTo(x + 14, y + 11); path.lineTo(x - 14, y + 11); path.close()
                cv.drawPath(path, p)
            }
        }
        p.style = Paint.Style.FILL
    }

    private fun stick(cv: Canvas, x: Float, y: Float, ax: Float, ay: Float, click: Boolean) {
        p.style = Paint.Style.FILL; p.color = 0xFF14171C.toInt()
        cv.drawCircle(x, y, 58f, p)
        stroke(cv) { it.drawCircle(x, y, 58f, p) }
        val moving = abs(ax) > 0.05f || abs(ay) > 0.05f
        val tx = x + ax * 30f; val ty = y + ay * 30f
        p.style = Paint.Style.FILL
        p.color = if (click) LIGHT else if (moving) CYAN else IDLE
        cv.drawCircle(tx, ty, 36f, p)
        stroke(cv) { it.drawCircle(tx, ty, 36f, p) }
    }
}
