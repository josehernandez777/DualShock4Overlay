# DualShock Overlay (Android 10+, Kotlin)

Overlay flotante que muestra un DualShock 4 (Bluetooth) con botones iluminados y sticks en tiempo real.
Sin root, sin anuncios, sin red (el manifest no pide INTERNET).

## Compilar el APK
Requisitos: Android Studio Koala+ (JDK 17 incluido), Android SDK 34.

1. `File > Open` y elige la carpeta `DualShockOverlay`. Acepta la sincronización de Gradle
   (si falta `gradlew`, Android Studio usa `gradle-wrapper.properties`; o ejecuta `gradle wrapper --gradle-version 8.7`).
2. APK debug: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   -> `app/build/outputs/apk/debug/app-debug.apk`
3. APK release (firmado con clave debug, instalable): `./gradlew assembleRelease`
   -> `app/build/outputs/apk/release/app-release.apk`
4. Copia el APK al móvil, permite "instalar apps desconocidas" e instálalo
   (o `adb install -r app-debug.apk`).

## Primer uso
1. Empareja el DS4 (mantén PS + Share hasta que parpadee) en Ajustes > Bluetooth.
2. Abre la app > "Permitir mostrar sobre otras apps".
3. "Activar lectura de botones en segundo plano" > Accesibilidad > DualShock Overlay > Activar.
   (Android 13+: si aparece "Ajuste restringido", Info de la app > ⋮ > Permitir ajustes restringidos.)
4. "Iniciar overlay". Controles: arrastra con un dedo, pellizca para redimensionar, o usa los sliders.
   Con "Bloquear" activado el toque atraviesa el overlay hacia el juego.
   La notificación tiene botones Ocultar/Mostrar, Bloquear y Cerrar.
5. Note 9: desactiva la optimización de batería para la app (Ajustes > Apps > DualShock Overlay > Batería)
   para que Samsung no mate el servicio.

## Qué funciona y qué NO (límites reales de Android, sin root)
Android entrega eventos de mando (KeyEvent/MotionEvent) SOLO a la ventana con foco. El overlay usa
FLAG_NOT_FOCUSABLE (obligatorio para no interferir con el juego), por lo que no recibe eventos por sí mismo.

| Entrada | App en primer plano | Overlay sobre un juego (vía Accesibilidad) |
|---|---|---|
| X, O, □, △, L1, R1, Share, Options, PS, L3, R3 | Sí | Sí (KeyEvent) |
| L2 / R2 digital (pulsado) | Sí | Sí |
| L2 / R2 analógico (%) | Sí | No |
| Sticks (movimiento analógico) | Sí | No |
| Cruceta | Sí | Normalmente no (es un eje HAT, no una tecla) |

- AccessibilityService.onKeyEvent solo recibe teclas; los MotionEvent de joystick no se exponen a servicios
  de accesibilidad en Android 10 (el Note 9 se queda en Android 10).
- Leer `/dev/input/event*` directamente requiere root o permisos de shell. Alternativas fuera del alcance
  pedido: un helper iniciado por ADB/Shizuku que lea esos eventos y los reenvíe a la app.
- El servicio de accesibilidad NO consume eventos (devuelve false): el juego los sigue recibiendo.
- Algunos juegos/apps con FLAG_SECURE, o con diálogos de sistema, pueden ocultar overlays.
  Android 12+ restringe toques sobre ventanas superpuestas: por eso el modo Bloqueado usa NOT_TOUCHABLE.
- Si otra app de accesibilidad ya filtra teclas, Android puede entregar solo a una de ellas.
- Mapeo de ejes (DS4 en Android): LS=X/Y, RS=Z/RZ, gatillos=LTRIGGER/RTRIGGER (con respaldo BRAKE/GAS, RX/RY).
  La línea gris inferior de la app muestra los eventos crudos para depurar otros firmwares.
- No probado en dispositivo físico por quien generó este proyecto (sin acceso a SDK/emulador): valida en tu Note 9.

## Cambios v1.1
- Cruceta: ya no reacciona al stick izquierdo (Android generaba teclas DPAD sintéticas; ahora se lee solo el eje HAT real).
- Con la app cerrada/en segundo plano, los sticks y gatillos analógicos se muestran apagados y centrados
  en lugar de quedarse congelados en la última posición.
- Rediseño del mando (silueta DS4, degradados, flechas de cruceta, brillo en pulsación) y de la interfaz.

## Barra LED RGB (pantalla "Barra LED RGB del mando")
### Qué se investigó
- Formato real (Linux hid-sony/hid-playstation, Chromium): por Bluetooth el DS4 usa el informe de salida
  `0x11` de 78 bytes: RGB en los bytes 8-10, parpadeo en 11-12 y un CRC32 final calculado sobre `0xA2` + los
  74 primeros bytes. Por USB es el informe `0x05` (RGB en 6-8). CUH-ZCT1 (PID 0x05C4) y CUH-ZCT2 (PID 0x09CC)
  usan el mismo informe; el adaptador inalámbrico es el 0x0BA0.
- Android 10: `BluetoothHidDevice` (público, API 28) solo permite actuar COMO dispositivo HID, no escribir en un
  mando. No existe API pública de "HID host" con informes de salida. `InputDevice.getLightsManager()` llega con
  Android 12; el Note 9 se queda en Android 10.
- Única vía sin root: el perfil HID Host interno (clase oculta `BluetoothInputDevice`, `BluetoothHidHost` en
  Android 11+) por reflexión: `sendData(device, hex)` (canal interrupt) y `setReport(device, 2, hex)` (canal control).
  La app los trata como API oculta y por eso usa `targetSdk 28` (las listas "max-target-p" siguen accesibles).

### Qué NO está verificado
- Quien generó el proyecto no tiene un Note 9 ni un DS4: **no se ha probado en hardware real**.
- Samsung puede bloquear esos métodos. Si es así la pantalla lo muestra ("API oculta BLOQUEADA") y ningún
  botón fingirá éxito.
- Cuando Android responde "aceptó el envío" solo significa que encoló el informe. La app pregunta al usuario si
  el LED físico cambió ("Sí / No") y solo entonces lo marca como confirmado.
- Mientras un juego use vibración, el kernel puede reenviar su color por defecto y pisar el tuyo.

### Alternativas si el bloqueo es total (todas con inconvenientes)
1. Desactivar la restricción de APIs ocultas una vez con ADB desde un PC (sin root):
   `adb shell settings put global hidden_api_policy 1` y reiniciar la app. Es un ajuste conocido; no verificado
   aquí en Android 10 de Samsung.
2. Cable USB (OTG) y `UsbManager` con el informe `0x05`: es API pública, pero reclamar la interfaz desconecta
   el mando como entrada de Android mientras dura y el LED vuelve al valor por defecto al devolverla.
3. Root, o un puente externo (PC/Raspberry con Bluetooth) que envíe el informe 0x11.
