# DualShock Overlay (Android 10+, Kotlin)

Overlay flotante que muestra un DualShock 4 (Bluetooth) con botones iluminados y sticks en tiempo real.
Sin root, sin anuncios, sin red (el manifest no pide INTERNET).

## Compilar el APK
Requisitos: Android Studio Koala+ (JDK 17 incluido), Android SDK 34.

1. `File > Open` y elige la carpeta `DualShockOverlay`. Acepta la sincronización de Gradle
   (si falta `gradlew`, Android Studio usa `gradle-wrapper.properties`; o ejecuta `gradle wrapper --gradle-version 8.7`).
2. APK debug: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   -> `app/build/outputs/apk/debug/app-debug.apk`
3. APK release (firmado con clave debug, instalable): `./gradlew assembleRelease`
   -> `app/build/outputs/apk/release/app-release.apk`
4. Copia el APK al móvil, permite "instalar apps desconocidas" e instálalo
   (o `adb install -r app-debug.apk`).

## Primer uso
1. Empareja el DS4 (mantén PS + Share hasta que parpadee) en Ajustes > Bluetooth.
2. Abre la app > "Permitir mostrar sobre otras apps".
3. "Activar lectura de botones en segundo plano" > Accesibilidad > DualShock Overlay > Activar.
   (Android 13+: si aparece "Ajuste restringido", Info de la app > ⋮ > Permitir ajustes restringidos.)
4. "Iniciar overlay". Controles: arrastra con un dedo, pellizca para redimensionar, o usa los sliders.
   Con "Bloquear" activado el toque atraviesa el overlay hacia el juego.
   La notificación tiene botones Ocultar/Mostrar, Bloquear y Cerrar.
5. Note 9: desactiva la optimización de batería para la app (Ajustes > Apps > DualShock Overlay > Batería)
   para que Samsung no mate el servicio.

## Qué funciona y qué NO (límites reales de Android, sin root)
Android entrega eventos de mando (KeyEvent/MotionEvent) SOLO a la ventana con foco. El overlay usa
FLAG_NOT_FOCUSABLE (obligatorio para no interferir con el juego), por lo que no recibe eventos por sí mismo.

| Entrada | App en primer plano | Overlay sobre un juego (vía Accesibilidad) |
|---|---|---|
| X, O, □, △, L1, R1, Share, Options, PS, L3, R3 | Sí | Sí (KeyEvent) |
| L2 / R2 digital (pulsado) | Sí | Sí |
| L2 / R2 analógico (%) | Sí | No |
| Sticks (movimiento analógico) | Sí | No |
| Cruceta | Sí | Normalmente no (es un eje HAT, no una tecla) |

- AccessibilityService.onKeyEvent solo recibe teclas; los MotionEvent de joystick no se exponen a servicios
  de accesibilidad en Android 10 (el Note 9 se queda en Android 10).
- Leer `/dev/input/event*` directamente requiere root o permisos de shell. Alternativas fuera del alcance
  pedido: un helper iniciado por ADB/Shizuku que lea esos eventos y los reenvíe a la app.
- El servicio de accesibilidad NO consume eventos (devuelve false): el juego los sigue recibiendo.
- Algunos juegos/apps con FLAG_SECURE, o con diálogos de sistema, pueden ocultar overlays.
  Android 12+ restringe toques sobre ventanas superpuestas: por eso el modo Bloqueado usa NOT_TOUCHABLE.
- Si otra app de accesibilidad ya filtra teclas, Android puede entregar solo a una de ellas.
- Mapeo de ejes (DS4 en Android): LS=X/Y, RS=Z/RZ, gatillos=LTRIGGER/RTRIGGER (con respaldo BRAKE/GAS, RX/RY).
  La línea gris inferior de la app muestra los eventos crudos para depurar otros firmwares.
- No probado en dispositivo físico por quien generó este proyecto (sin acceso a SDK/emulador): valida en tu Note 9.
