package com.dualshock.overlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

/** Dibuja el DualShock 4 en un espacio virtual de 1000x620. */
class GamepadView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val rect = RectF()
    private val path = Path()
    private val body = Path()
    private val listener: () -> Unit = { invalidate() }

    private val IDLE = 0xFF3B424D.toInt()
    private val EDGE = 0xFF5E6674.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val CYAN = 0xFF4FC3F7.toInt()
    private val DARK = 0xFF0B1A22.toInt()
    private val CROSS = 0xFF5C8DFF.toInt()
    private val CIRCLE = 0xFFFF5252.toInt()
    private val SQUARE = 0xFFFF80C0.toInt()
    private val TRI = 0xFF4CD97B.toInt()

    private val bodyShader = LinearGradient(0f, 130f, 0f, 620f, 0xFF363C47.toInt(), 0xFF171A1F.toInt(), Shader.TileMode.CLAMP)
    private val padShader = LinearGradient(0f, 170f, 0f, 300f, 0xFF242932.toInt(), 0xFF12151A.toInt(), Shader.TileMode.CLAMP)

    init {
        body.moveTo(250f, 140f)
        body.cubicTo(330f, 120f, 400f, 135f, 500f, 135f)
        body.cubicTo(600f, 135f, 670f, 120f, 750f, 140f)
        body.cubicTo(830f, 160f, 900f, 230f, 950f, 350f)
        body.cubicTo(990f, 450f, 985f, 570f, 920f, 600f)
        body.cubicTo(860f, 625f, 790f, 590f, 745f, 510f)
        body.cubicTo(720f, 470f, 690f, 455f, 640f, 455f)
        body.lineTo(360f, 455f)
        body.cubicTo(310f, 455f, 280f, 470f, 255f, 510f)
        body.cubicTo(210f, 590f, 140f, 625f, 80f, 600f)
        body.cubicTo(15f, 570f, 10f, 450f, 50f, 350f)
        body.cubicTo(100f, 230f, 170f, 160f, 250f, 140f)
        body.close()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); GamepadRepo.addListener(listener) }
    override fun onDetachedFromWindow() { GamepadRepo.removeListener(listener); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w).let { if (it <= 0) 800 else it }
        setMeasuredDimension(width, (width * 0.62f).toInt())
    }

    private fun down(k: Int) = GamepadRepo.pressed.contains(k)

    override fun onDraw(cv: Canvas) {
        cv.save()
        cv.scale(width / 1000f, height / 620f)
        val s = GamepadRepo
        val live = s.analogLive

        // Cuerpo
        p.style = Paint.Style.FILL; p.shader = bodyShader; cv.drawPath(body, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = EDGE; cv.drawPath(body, p)

        // Barra de luz y touchpad
        p.style = Paint.Style.FILL; p.color = 0xFF2962FF.toInt()
        rect.set(430f, 134f, 570f, 142f); cv.drawRoundRect(rect, 4f, 4f, p)
        rect.set(385f, 170f, 615f, 300f)
        p.shader = padShader; cv.drawRoundRect(rect, 22f, 22f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = EDGE; cv.drawRoundRect(rect, 22f, 22f, p)

        // Gatillos y hombros
        val l2v = if (down(KeyEvent.KEYCODE_BUTTON_L2)) 1f else s.l2
        val r2v = if (down(KeyEvent.KEYCODE_BUTTON_R2)) 1f else s.r2
        trigger(cv, 180f, 300f, l2v, "L2", live)
        trigger(cv, 700f, 820f, r2v, "R2", live)
        bumper(cv, 150f, 330f, down(KeyEvent.KEYCODE_BUTTON_L1), "L1")
        bumper(cv, 670f, 850f, down(KeyEvent.KEYCODE_BUTTON_R1), "R1")

        // Share / Options
        btnRR(cv, 322f, 178f, 346f, 214f, 8f, down(KeyEvent.KEYCODE_BUTTON_SELECT), CYAN)
        btnRR(cv, 654f, 178f, 678f, 214f, 8f, down(KeyEvent.KEYCODE_BUTTON_START), CYAN)
        label(cv, "SHARE", 334f, 232f, 14f, 0xFF8B97A6.toInt())
        label(cv, "OPTIONS", 666f, 232f, 14f, 0xFF8B97A6.toInt())

        // Cruceta (solo HAT real o teclas DPAD de un mando sin HAT)
        val cx = 240f; val cy = 265f
        arm(cv, cx - 24, cy - 78, cx + 24, cy - 22, s.hatY < -0.5f || down(KeyEvent.KEYCODE_DPAD_UP), 0)
        arm(cv, cx - 24, cy + 22, cx + 24, cy + 78, s.hatY > 0.5f || down(KeyEvent.KEYCODE_DPAD_DOWN), 1)
        arm(cv, cx - 78, cy - 24, cx - 22, cy + 24, s.hatX < -0.5f || down(KeyEvent.KEYCODE_DPAD_LEFT), 2)
        arm(cv, cx + 22, cy - 24, cx + 78, cy + 24, s.hatX > 0.5f || down(KeyEvent.KEYCODE_DPAD_RIGHT), 3)

        // Botones de cara
        face(cv, 760f, 197f, down(KeyEvent.KEYCODE_BUTTON_Y), TRI, 3)
        face(cv, 828f, 265f, down(KeyEvent.KEYCODE_BUTTON_B), CIRCLE, 1)
        face(cv, 760f, 333f, down(KeyEvent.KEYCODE_BUTTON_A), CROSS, 0)
        face(cv, 692f, 265f, down(KeyEvent.KEYCODE_BUTTON_X), SQUARE, 2)

        // PS
        val ps = down(KeyEvent.KEYCODE_BUTTON_MODE)
        if (ps) { p.style = Paint.Style.STROKE; p.strokeWidth = 12f; p.color = 0x55FFFFFF; cv.drawCircle(500f, 395f, 21f, p) }
        p.style = Paint.Style.FILL; p.color = if (ps) WHITE else IDLE; cv.drawCircle(500f, 395f, 21f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = EDGE; cv.drawCircle(500f, 395f, 21f, p)

        // Sticks
        stick(cv, 390f, 395f, s.lx, s.ly, down(KeyEvent.KEYCODE_BUTTON_THUMBL), live)
        stick(cv, 610f, 395f, s.rx, s.ry, down(KeyEvent.KEYCODE_BUTTON_THUMBR), live)
        cv.restore()
    }

    private fun fillRR(cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, glow: Int) {
        rect.set(l, t, r, b)
        if (glow != 0) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = (glow and 0x00FFFFFF) or 0x55000000
            cv.drawRoundRect(rect, rad, rad, p)
        }
        p.style = Paint.Style.FILL; p.color = fill; cv.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = EDGE; cv.drawRoundRect(rect, rad, rad, p)
    }

    private fun btnRR(cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, lit: Boolean, color: Int) =
        fillRR(cv, l, t, r, b, rad, if (lit) color else IDLE, if (lit) color else 0)

    private fun label(cv: Canvas, text: String, x: Float, y: Float, size: Float, color: Int) {
        tp.textSize = size; tp.color = color; cv.drawText(text, x, y, tp)
    }

    private fun bumper(cv: Canvas, l: Float, r: Float, lit: Boolean, t: String) {
        btnRR(cv, l, 78f, r, 128f, 24f, lit, CYAN)
        label(cv, t, (l + r) / 2, 113f, 28f, if (lit) DARK else 0xFFB0BEC5.toInt())
    }

    private fun trigger(cv: Canvas, l: Float, r: Float, v: Float, t: String, live: Boolean) {
        val top = 6f; val bot = 62f
        fillRR(cv, l, top, r, bot, 16f, IDLE, 0)
        if (v > 0.02f) {
            val h = (bot - top - 6f) * v.coerceIn(0f, 1f)
            rect.set(l + 3, bot - 3 - h, r - 3, bot - 3)
            p.style = Paint.Style.FILL; p.color = CYAN; cv.drawRoundRect(rect, 12f, 12f, p)
        }
        val txt = if (live) "$t ${(v * 100).toInt()}%" else t
        label(cv, txt, (l + r) / 2, 44f, 24f, if (v > 0.6f) DARK else WHITE)
    }

    private fun arm(cv: Canvas, l: Float, t: Float, r: Float, b: Float, lit: Boolean, dir: Int) {
        btnRR(cv, l, t, r, b, 8f, lit, CYAN)
        val cx = (l + r) / 2; val cy = (t + b) / 2
        path.reset()
        when (dir) {
            0 -> { path.moveTo(cx, cy - 8); path.lineTo(cx - 9, cy + 6); path.lineTo(cx + 9, cy + 6) }
            1 -> { path.moveTo(cx, cy + 8); path.lineTo(cx - 9, cy - 6); path.lineTo(cx + 9, cy - 6) }
            2 -> { path.moveTo(cx - 8, cy); path.lineTo(cx + 6, cy - 9); path.lineTo(cx + 6, cy + 9) }
            else -> { path.moveTo(cx + 8, cy); path.lineTo(cx - 6, cy - 9); path.lineTo(cx - 6, cy + 9) }
        }
        path.close()
        p.style = Paint.Style.FILL; p.color = if (lit) DARK else 0xFF6B7482.toInt(); cv.drawPath(path, p)
    }

    private fun face(cv: Canvas, x: Float, y: Float, lit: Boolean, color: Int, kind: Int) {
        if (lit) { p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = (color and 0x00FFFFFF) or 0x55000000; cv.drawCircle(x, y, 33f, p) }
        p.style = Paint.Style.FILL; p.color = if (lit) color else IDLE; cv.drawCircle(x, y, 33f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = EDGE; cv.drawCircle(x, y, 33f, p)
        p.strokeWidth = 6f; p.color = if (lit) DARK else color
        when (kind) {
            0 -> { cv.drawLine(x - 12, y - 12, x + 12, y + 12, p); cv.drawLine(x + 12, y - 12, x - 12, y + 12, p) }
            1 -> cv.drawCircle(x, y, 13f, p)
            2 -> { rect.set(x - 12, y - 12, x + 12, y + 12); cv.drawRect(rect, p) }
            else -> {
                path.reset(); path.moveTo(x, y - 15); path.lineTo(x + 14, y + 11); path.lineTo(x - 14, y + 11); path.close()
                cv.drawPath(path, p)
            }
        }
    }

    private fun stick(cv: Canvas, x: Float, y: Float, ax: Float, ay: Float, click: Boolean, live: Boolean) {
        p.style = Paint.Style.FILL; p.color = 0xFF0F1115.toInt(); cv.drawCircle(x, y, 60f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = EDGE; cv.drawCircle(x, y, 60f, p)
        val mag = max(1f, hypot(ax, ay))
        val tx = x + ax / mag * 26f; val ty = y + ay / mag * 26f
        val moving = live && hypot(ax, ay) > 0.05f
        if (moving) { p.strokeWidth = 5f; p.color = 0x664FC3F7; cv.drawLine(x, y, tx, ty, p) }
        val fill = when { click -> WHITE; !live -> 0xFF2A2E35.toInt(); moving -> CYAN; else -> IDLE }
        p.style = Paint.Style.FILL; p.color = fill; cv.drawCircle(tx, ty, 38f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = EDGE; cv.drawCircle(tx, ty, 38f, p)
        p.strokeWidth = 2f; p.color = if (fill == CYAN || fill == WHITE) 0x55000000 else 0x33FFFFFF
        cv.drawCircle(tx, ty, 22f, p)
    }
}
