package com.dualshock.overlay

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.max

/** Estado global del mando. Todo se actualiza en el hilo principal. */
object GamepadRepo {
    val pressed = HashSet<Int>()
    var lx = 0f; var ly = 0f
    var rx = 0f; var ry = 0f
    var l2 = 0f; var r2 = 0f
    var hatX = 0f; var hatY = 0f
    var lastInfo = "Sin eventos todavía"

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun notifyChange() { listeners.forEach { it() } }

    fun init(ctx: Context) {
        val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(id: Int) {}
            override fun onInputDeviceChanged(id: Int) {}
            override fun onInputDeviceRemoved(id: Int) { if (connectedPads().isEmpty()) reset() }
        }, Handler(Looper.getMainLooper()))
    }

    fun reset() {
        pressed.clear()
        lx = 0f; ly = 0f; rx = 0f; ry = 0f; l2 = 0f; r2 = 0f; hatX = 0f; hatY = 0f
        notifyChange()
    }

    fun isPadSource(src: Int) =
        (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
        (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK

    fun connectedPads(): List<InputDevice> =
        InputDevice.getDeviceIds().toList().mapNotNull { InputDevice.getDevice(it) }
            .filter { !it.isVirtual && isPadSource(it.sources) }

    fun isDualShock4(d: InputDevice) =
        d.vendorId == 0x054c && (d.productId == 0x05c4 || d.productId == 0x09cc || d.productId == 0x081f)

    private fun isDpadKey(k: Int) = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
        k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT

    /** Nunca consume el evento: solo lo observa. */
    fun onKey(e: KeyEvent) {
        if (!isPadSource(e.source)) return
        val k = e.keyCode
        if (!KeyEvent.isGamepadButton(k) && !isDpadKey(k)) return
        when (e.action) {
            KeyEvent.ACTION_DOWN -> pressed.add(k)
            KeyEvent.ACTION_UP -> pressed.remove(k)
            else -> return
        }
        lastInfo = "KEY ${KeyEvent.keyCodeToString(k)} ${if (e.action == KeyEvent.ACTION_DOWN) "DOWN" else "UP"}"
        notifyChange()
    }

    fun onMotion(e: MotionEvent) {
        if (!isPadSource(e.source) || e.action != MotionEvent.ACTION_MOVE) return
        val dev = e.device
        val hasZ = dev?.getMotionRange(MotionEvent.AXIS_Z, e.source) != null
        val rxAxis = if (hasZ) MotionEvent.AXIS_Z else MotionEvent.AXIS_RX
        val ryAxis = if (hasZ) MotionEvent.AXIS_RZ else MotionEvent.AXIS_RY
        lx = dz(e.getAxisValue(MotionEvent.AXIS_X)); ly = dz(e.getAxisValue(MotionEvent.AXIS_Y))
        rx = dz(e.getAxisValue(rxAxis)); ry = dz(e.getAxisValue(ryAxis))
        l2 = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
        r2 = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
        hatX = e.getAxisValue(MotionEvent.AXIS_HAT_X); hatY = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        lastInfo = "LS(%.2f,%.2f) RS(%.2f,%.2f) L2=%.2f R2=%.2f HAT(%.0f,%.0f)"
            .format(lx, ly, rx, ry, l2, r2, hatX, hatY)
        notifyChange()
    }

    private fun dz(v: Float) = if (abs(v) < 0.06f) 0f else v.coerceIn(-1f, 1f)
}
