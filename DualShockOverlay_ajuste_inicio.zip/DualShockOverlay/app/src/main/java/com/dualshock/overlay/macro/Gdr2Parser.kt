package com.dualshock.overlay.macro

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Lector de Geometry Dash Replay v2 (.gdr2, maxnut/GDReplayFormat).
 *
 * Verificado contra un archivo real de EclipseBot: la cabecera se lee entera, los inputs terminan exactamente en
 * el último byte y la suma de frames coincide con duración × fps. OJO: el README oficial describe el empaquetado
 * de cada input con "bit0 = continuación"; los archivos reales usan un varint LEB128 estándar con
 * packed = (delta << 1) | down, y es lo que se implementa aquí.
 *
 * Soporta: juego normal (no platformer), input tag vacío (EclipseBot y similares), solo jugador 1.
 */
object Gdr2Parser {
    @Volatile var lastNote = ""
    private const val MIN_HOLD_MS = 10L

    fun isGdr(b: ByteArray) =
        b.size > 4 && b[0] == 'G'.code.toByte() && b[1] == 'D'.code.toByte() && b[2] == 'R'.code.toByte()

    private class Reader(val b: ByteArray) {
        var pos = 0
        fun u8(): Int {
            if (pos >= b.size) throw IllegalArgumentException("archivo .gdr2 truncado")
            return b[pos++].toInt() and 0xFF
        }
        fun varint(): Long {
            var v = 0L
            var s = 0
            while (true) {
                val x = u8()
                v = v or ((x and 0x7F).toLong() shl s)
                if ((x and 0x80) == 0) return v
                s += 7
                if (s > 63) throw IllegalArgumentException("número demasiado largo en el .gdr2")
            }
        }
        fun skip(n: Long) {
            if (n < 0 || pos + n > b.size) throw IllegalArgumentException("archivo .gdr2 truncado")
            pos += n.toInt()
        }
        fun str(): String {
            val n = varint()
            if (n < 0 || pos + n > b.size) throw IllegalArgumentException("texto fuera de rango en el .gdr2")
            val s = String(b, pos, n.toInt(), Charsets.UTF_8)
            pos += n.toInt()
            return s
        }
        fun doubleBE(): Double {
            if (pos + 8 > b.size) throw IllegalArgumentException("archivo .gdr2 truncado")
            val v = ByteBuffer.wrap(b, pos, 8).order(ByteOrder.BIG_ENDIAN).double
            pos += 8
            return v
        }
    }

    fun parse(name: String, b: ByteArray): Macro {
        val r = Reader(b)
        r.skip(3)                                   // "GDR"
        val version = r.varint()
        if (version != 2L) throw IllegalArgumentException("versión de GDR no soportada ($version): solo .gdr2")
        val tag = r.str()
        r.str(); r.str()                            // autor, descripción
        r.skip(4)                                   // duración (float32 big-endian)
        r.varint()                                  // versión del juego
        val fps = r.doubleBE()
        r.varint(); r.varint()                      // seed, monedas
        r.u8()                                      // LDM
        val platformer = r.u8() != 0
        val bot = r.str(); r.varint()               // bot y versión
        r.varint()                                  // id del nivel
        val level = r.str()
        r.skip(r.varint())                          // extensión del replay
        repeat(r.varint().toInt()) { r.varint() }   // frames de muerte

        if (tag.isNotEmpty()) throw IllegalArgumentException("input tag «$tag» no soportado")
        if (platformer) throw IllegalArgumentException("los replays de platformer no están soportados")
        if (!(fps > 0.0)) throw IllegalArgumentException("framerate no válido")

        val total = r.varint()
        val p1 = r.varint()
        if (total < 0 || total > 200_000 || p1 < 0 || p1 > total) throw IllegalArgumentException("número de inputs no válido")

        val holds = ArrayList<Hold>()
        var frame = 0L
        var downAt = -1L
        var p2 = 0
        for (i in 0 until total.toInt()) {
            val packed = r.varint()
            if (i.toLong() == p1) frame = 0L        // los inputs del jugador 2 reinician su propia cuenta de frames
            frame += packed shr 1
            if (i.toLong() >= p1) { p2++; continue }
            val t = Math.round(frame * 1000.0 / fps)
            if ((packed and 1L) == 1L) {
                if (downAt < 0) downAt = t
            } else if (downAt >= 0) {
                holds.add(Hold(downAt, maxOf(MIN_HOLD_MS, t - downAt)))
                downAt = -1L
            }
        }
        if (downAt >= 0) holds.add(Hold(downAt, 100L))
        if (holds.isEmpty()) throw IllegalArgumentException("el replay no contiene ninguna pulsación del jugador 1")

        lastNote = "$bot · «$level» · ${holds.size} toques del jugador 1 (${p2} entradas del jugador 2 ignoradas)"
        return Macro(name, holds)
    }
}
