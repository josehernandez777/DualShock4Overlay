package com.dualshock.overlay.macro

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.dualshock.overlay.GamepadAccessibilityService
import com.dualshock.overlay.R
import java.util.Locale

class MacroActivity : Activity() {

    companion object { private const val REQ_IMPORT = 41 }

    private lateinit var list: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_macro)
        list = findViewById(R.id.macroList)

        findViewById<Button>(R.id.btnImport).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, REQ_IMPORT)
        }
        findViewById<Button>(R.id.btnSample).setOnClickListener {
            MacroPrefs.setSelected(this, MacroStore.createSample(this)); rebuildList(); refresh()
        }
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            MacroPrefs.selected(this)?.let { MacroStore.delete(this, it) }
            MacroPrefs.setSelected(this, null); rebuildList(); refresh()
        }

        val kSq = findViewById<Button>(R.id.kSquare); val kSh = findViewById<Button>(R.id.kShare)
        fun setStart(k: Int) {
            MacroPrefs.setStartKey(this, k)
            style(kSq, k == MacroPrefs.SQUARE); style(kSh, k == MacroPrefs.SHARE)
            MacroPlayer.refreshUi()
        }
        kSq.setOnClickListener { setStart(MacroPrefs.SQUARE) }
        kSh.setOnClickListener { setStart(MacroPrefs.SHARE) }
        setStart(MacroPrefs.startKey(this).let { if (it == MacroPrefs.SHARE) it else MacroPrefs.SQUARE })

        val sOp = findViewById<Button>(R.id.sOptions); val sTr = findViewById<Button>(R.id.sTriangle); val sCi = findViewById<Button>(R.id.sCircle)
        fun setStop(k: Int) {
            MacroPrefs.setStopKey(this, k)
            style(sOp, k == MacroPrefs.OPTIONS); style(sTr, k == MacroPrefs.TRIANGLE); style(sCi, k == MacroPrefs.CIRCLE)
        }
        sOp.setOnClickListener { setStop(MacroPrefs.OPTIONS) }
        sTr.setOnClickListener { setStop(MacroPrefs.TRIANGLE) }
        sCi.setOnClickListener { setStop(MacroPrefs.CIRCLE) }
        setStop(MacroPrefs.stopKey(this).let { if (it == MacroPrefs.TRIANGLE || it == MacroPrefs.CIRCLE) it else MacroPrefs.OPTIONS })

        val sw = findViewById<Switch>(R.id.swArmed)
        sw.isChecked = MacroPrefs.armed(this)
        sw.setOnCheckedChangeListener { _, on ->
            MacroPrefs.setArmed(this, on)
            if (on && MacroPrefs.selected(this) == null)
                Toast.makeText(this, "Selecciona primero una macro", Toast.LENGTH_SHORT).show()
            MacroPlayer.refreshUi()
        }

        bindSeek(R.id.sbX, R.id.tvX, "macro_x", MacroPrefs.xPct(this), 1) { "Posición del toque X  $it %" }
        bindSeek(R.id.sbY, R.id.tvY, "macro_y", MacroPrefs.yPct(this), 1) { "Posición del toque Y  $it %" }
        bindSeek(R.id.sbDelay, R.id.tvDelay, "macro_delay", MacroPrefs.delayMs(this) / 50, 50) { "Retardo inicial  ${it} ms" }
        bindSeek(R.id.sbLead, R.id.tvLead, "macro_lead", MacroPrefs.leadMs(this) / 5, 5) { "Adelanto por latencia  ${it} ms" }

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            Toast.makeText(this, "Cambia a Geometry Dash: la macro empieza en 3 s", Toast.LENGTH_LONG).show()
            val app = applicationContext
            ui.postDelayed({ MacroPlayer.start(app, "botón de la app") }, 3000)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { MacroPlayer.stop("botón de la app") }

        rebuildList()
    }

    /** SeekBar con valor = progreso * step; guarda en Prefs y actualiza su etiqueta. */
    private fun bindSeek(sbId: Int, tvId: Int, key: String, progress: Int, step: Int, label: (Int) -> String) {
        val sb = findViewById<SeekBar>(sbId); val tv = findViewById<TextView>(tvId)
        sb.progress = progress
        tv.text = label(progress * step)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                MacroPrefs.setInt(this@MacroActivity, key, p * step)
                tv.text = label(p * step)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun style(b: TextView, on: Boolean) {
        b.setBackgroundResource(if (on) R.drawable.btn_primary else R.drawable.btn_secondary)
        b.setTextColor(if (on) 0xFF06202B.toInt() else 0xFFE6EDF3.toInt())
    }

    private fun rebuildList() {
        list.removeAllViews()
        val names = MacroStore.list(this)
        val sel = MacroPrefs.selected(this)
        if (names.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No hay macros. Importa un archivo o crea la macro de prueba."
                setTextColor(0xFF8B97A6.toInt()); textSize = 13f
            })
            return
        }
        for (n in names) {
            val tv = TextView(this).apply {
                text = n; textSize = 14f
                setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(6) }
                setOnClickListener { MacroPrefs.setSelected(this@MacroActivity, n); rebuildList(); refresh() }
            }
            style(tv, n == sel)
            list.addView(tv)
        }
    }

    private fun chip(id: Int, ok: Boolean?, text: String) {
        val sb = SpannableStringBuilder("●  $text")
        val c = when (ok) { true -> 0xFF4CD97B; false -> 0xFFFF6B6B; null -> 0xFF8B97A6 }.toInt()
        sb.setSpan(ForegroundColorSpan(c), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        findViewById<TextView>(id).text = sb
    }

    private fun refresh() {
        val svc = GamepadAccessibilityService.instance
        when {
            svc == null -> chip(R.id.chipSvc, false, "Accesibilidad: servicio no activo")
            !svc.canGestures() -> chip(R.id.chipSvc, false, "Accesibilidad activa pero SIN permiso de gestos: desactívala y vuelve a activarla")
            else -> chip(R.id.chipSvc, true, "Accesibilidad: lista (toques permitidos)")
        }
        val playing = MacroPlayer.state == MacroPlayer.State.PLAYING
        chip(R.id.chipState, if (playing) true else null,
            if (playing) String.format(Locale.US, "Reproduciendo «%s»  %.1f / %.1f s", MacroPlayer.macroName, MacroPlayer.elapsedMs / 1000f, MacroPlayer.totalMs / 1000f)
            else MacroPlayer.lastMessage)
        val sel = MacroPrefs.selected(this)
        chip(R.id.chipSel, sel != null, if (sel != null) "Macro seleccionada: $sel" else "Ninguna macro seleccionada")
        chip(R.id.chipArm, if (MacroPrefs.armed(this)) true else null,
            if (MacroPrefs.armed(this)) "Armada: el botón de inicio queda reservado para la macro" else "Desarmada: el botón funciona con normalidad en el juego")
        findViewById<TextView>(R.id.tvCounts).text =
            "Toques enviados al sistema: ${MacroPlayer.sent} · rechazados: ${MacroPlayer.rejected}\n(Que el sistema los acepte no garantiza que el juego los registre a tiempo.)"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_IMPORT && res == RESULT_OK) {
            val uri = data?.data ?: return
            val r = MacroStore.import(this, uri)
            if (r.name != null) { MacroPrefs.setSelected(this, r.name); Toast.makeText(this, "Importada: ${r.name}\n${r.info ?: ""}", Toast.LENGTH_LONG).show() }
            else Toast.makeText(this, r.error ?: "Error al importar", Toast.LENGTH_LONG).show()
            rebuildList(); refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        MacroPlayer.addListener(listener)
        findViewById<Switch>(R.id.swArmed).isChecked = MacroPrefs.armed(this)
        refresh()
    }

    override fun onPause() {
        MacroPlayer.removeListener(listener)
        super.onPause()
    }
}
