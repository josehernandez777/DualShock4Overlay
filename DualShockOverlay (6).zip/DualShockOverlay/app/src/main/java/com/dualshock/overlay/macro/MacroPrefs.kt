package com.dualshock.overlay.macro

import android.content.Context
import android.view.KeyEvent
import com.dualshock.overlay.Prefs

object MacroPrefs {
    // Android nombra al Cuadrado del DS4 como BUTTON_X y a Share como BUTTON_SELECT.
    const val SQUARE = KeyEvent.KEYCODE_BUTTON_X
    const val SHARE = KeyEvent.KEYCODE_BUTTON_SELECT
    const val OPTIONS = KeyEvent.KEYCODE_BUTTON_START
    const val TRIANGLE = KeyEvent.KEYCODE_BUTTON_Y
    const val CIRCLE = KeyEvent.KEYCODE_BUTTON_B

    private fun sp(c: Context) = Prefs.sp(c)
    fun selected(c: Context): String? = sp(c).getString("macro_sel", null)
    fun setSelected(c: Context, n: String?) = sp(c).edit().putString("macro_sel", n).apply()
    fun startKey(c: Context) = sp(c).getInt("macro_start", SQUARE)
    fun setStartKey(c: Context, k: Int) = sp(c).edit().putInt("macro_start", k).apply()
    fun stopKey(c: Context) = sp(c).getInt("macro_stop", OPTIONS)
    fun setStopKey(c: Context, k: Int) = sp(c).edit().putInt("macro_stop", k).apply()
    fun armed(c: Context) = sp(c).getBoolean("macro_armed", false)
    fun setArmed(c: Context, v: Boolean) = sp(c).edit().putBoolean("macro_armed", v).apply()
    fun xPct(c: Context) = sp(c).getInt("macro_x", 50)
    fun yPct(c: Context) = sp(c).getInt("macro_y", 50)
    fun delayMs(c: Context) = sp(c).getInt("macro_delay", 0)
    fun leadMs(c: Context) = sp(c).getInt("macro_lead", 0)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
}
