package com.dualshock.overlay.macro

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Una pulsación: dedo abajo en startMs durante durMs. */
data class Hold(val startMs: Long, val durMs: Long)

class Macro(val name: String, val holds: List<Hold>) {
    val totalMs: Long = holds.maxOf { it.startMs + it.durMs }
}

/**
 * Formato de texto (una línea por evento, '#' comenta):
 *   0,down        80,up        500,tap,60      (tiempo en ms; "tap" admite duración en ms)
 * Cabeceras opcionales:  fps=240   (los tiempos pasan a ser FRAMES)   unit=ms|frames
 */
object MacroParser {
    private class Raw(val t: Long, val kind: Int, val dur: Long)

    fun parse(name: String, text: String): Macro {
        var fps = 0.0
        var unit: String? = null
        val raws = ArrayList<Raw>()
        text.removePrefix("\uFEFF").lineSequence().forEachIndexed { idx, line0 ->
            val line = line0.substringBefore('#').substringBefore("//").trim()
            if (line.isEmpty()) return@forEachIndexed
            val n = idx + 1
            if (line.contains('=') && !line.contains(',')) {
                val key = line.substringBefore('=').trim().lowercase()
                val value = line.substringAfter('=').trim().lowercase()
                when (key) {
                    "fps" -> fps = value.toDoubleOrNull()?.takeIf { it > 0 }
                        ?: throw IllegalArgumentException("línea $n: fps no válido")
                    "unit" -> unit = value
                    else -> {}
                }
                return@forEachIndexed
            }
            val tok = line.split(',', ';', '\t', ' ').filter { it.isNotBlank() }
            if (tok.size < 2) throw IllegalArgumentException("línea $n: se esperaba «tiempo,acción»")
            val tv = tok[0].toDoubleOrNull() ?: throw IllegalArgumentException("línea $n: tiempo no válido «${tok[0]}»")
            val frames = (unit ?: if (fps > 0) "frames" else "ms").startsWith("f")
            if (frames && fps <= 0) throw IllegalArgumentException("línea $n: unit=frames requiere fps=…")
            val t = Math.round(if (frames) tv * 1000.0 / fps else tv)
            if (t < 0) throw IllegalArgumentException("línea $n: tiempo negativo")
            when (tok[1].lowercase()) {
                "down", "press", "d", "1", "true" -> raws.add(Raw(t, 1, 0))
                "up", "release", "u", "0", "false" -> raws.add(Raw(t, 0, 0))
                "tap", "click" -> raws.add(Raw(t, 2, tok.getOrNull(2)?.toDoubleOrNull()?.toLong() ?: 50L))
                else -> throw IllegalArgumentException("línea $n: acción desconocida «${tok[1]}»")
            }
        }
        val holds = ArrayList<Hold>()
        var downAt = -1L
        for (e in raws.sortedBy { it.t }) {
            when (e.kind) {
                1 -> if (downAt < 0) downAt = e.t
                0 -> if (downAt >= 0) { holds.add(Hold(downAt, maxOf(1L, e.t - downAt))); downAt = -1L }
                else -> {
                    if (downAt >= 0) { holds.add(Hold(downAt, maxOf(1L, e.t - downAt))); downAt = -1L }
                    holds.add(Hold(e.t, maxOf(1L, e.dur)))
                }
            }
        }
        if (downAt >= 0) holds.add(Hold(downAt, 100L))
        if (holds.isEmpty()) throw IllegalArgumentException("la macro no contiene ninguna pulsación")
        if (holds.size > 20000) throw IllegalArgumentException("demasiadas pulsaciones (máx. 20000)")
        return Macro(name, holds)
    }
}

object MacroStore {
    data class ImportResult(val name: String?, val error: String?)

    private fun dir(ctx: Context) = File(ctx.filesDir, "macros").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "macro.txt" }

    fun list(ctx: Context): List<String> =
        dir(ctx).listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList()

    fun load(ctx: Context, name: String): Macro = MacroParser.parse(name, File(dir(ctx), name).readText())

    fun delete(ctx: Context, name: String) { File(dir(ctx), name).delete() }

    fun import(ctx: Context, uri: Uri): ImportResult {
        return try {
            var display = "macro.txt"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.let { n -> display = n }
            }
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return ImportResult(null, "No se pudo abrir el archivo")
            if (bytes.size > 4_000_000) return ImportResult(null, "Archivo demasiado grande (máx. 4 MB)")
            val text = String(bytes, Charsets.UTF_8)
            val name = safe(display)
            MacroParser.parse(name, text)   // valida antes de guardar
            File(dir(ctx), name).writeText(text)
            ImportResult(name, null)
        } catch (e: Exception) {
            ImportResult(null, "Formato no válido: ${e.message}")
        }
    }

    fun createSample(ctx: Context): String {
        val name = "prueba_3_toques.txt"
        File(dir(ctx), name).writeText(
            "# Macro de prueba: 3 toques (tiempo en ms, acción)\n0,down\n80,up\n600,down\n680,up\n1200,down\n1700,up\n"
        )
        return name
    }
}
