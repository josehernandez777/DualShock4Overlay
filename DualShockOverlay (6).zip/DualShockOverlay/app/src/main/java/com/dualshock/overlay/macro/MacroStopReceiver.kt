package com.dualshock.overlay.macro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class MacroStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        MacroPlayer.stop("botón de la notificación")
    }
}
