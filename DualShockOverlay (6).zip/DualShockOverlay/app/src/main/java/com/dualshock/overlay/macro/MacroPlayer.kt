package com.dualshock.overlay.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.dualshock.overlay.GamepadAccessibilityService
import com.dualshock.overlay.OverlayService
import com.dualshock.overlay.Prefs
import com.dualshock.overlay.R
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Reproduce una macro como toques en pantalla mediante AccessibilityService.dispatchGesture
 * (única vía sin root). Todo corre en el hilo principal, así que "state" actúa de cerrojo:
 * una segunda orden de inicio mientras se reproduce se descarta.
 *
 * Limitación real: dispatchGesture no es preciso al frame. Hay latencia y jitter de decenas de ms.
 */
object MacroPlayer {
    enum class State { IDLE, PLAYING }

    private const val CHUNK_MS = 200L          // pausa máxima entre "puntos de parada" dentro de una pulsación larga
    private const val CH = "macro"
    private const val NOTIF = 3

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private var token = Any()
    private var baseUptime = 0L
    private var px = 0f
    private var py = 0f
    private var appCtx: Context? = null
    private var restoreUnlock = false

    @Volatile var state = State.IDLE
    @Volatile var macroName = ""
    @Volatile var elapsedMs = 0L
    @Volatile var totalMs = 0L
    @Volatile var lastMessage = "Inactivo"
    @Volatile var sent = 0
    @Volatile var rejected = 0
    @Volatile var holdActive = false      // true mientras la macro mantiene un toque (para el overlay)

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun refreshUi() = changed()
    private fun changed() { listeners.forEach { it() } }

    fun start(ctx: Context, source: String): Boolean {
        if (state == State.PLAYING) {
            lastMessage = "Ya hay una macro en curso: pulsación ignorada"; changed(); return false
        }
        val svc = GamepadAccessibilityService.instance
        if (svc == null) { lastMessage = "El servicio de accesibilidad no está activo"; changed(); return false }
        if (!svc.canGestures()) {
            lastMessage = "La accesibilidad no tiene permiso de gestos: desactívala y vuelve a activarla"; changed(); return false
        }
        val name = MacroPrefs.selected(ctx)
        if (name == null) { lastMessage = "No hay ninguna macro seleccionada"; changed(); return false }
        val macro = try { MacroStore.load(ctx, name) } catch (e: Exception) {
            lastMessage = "No se pudo leer la macro: ${e.message}"; changed(); return false
        }

        val app = ctx.applicationContext
        appCtx = app
        val dm = DisplayMetrics()
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        px = dm.widthPixels * MacroPrefs.xPct(app) / 100f
        py = dm.heightPixels * MacroPrefs.yPct(app) / 100f

        // Si el overlay es táctil, los toques en su zona no llegarían al juego: se bloquea mientras dura la macro.
        if (OverlayService.running && !Prefs.locked(app)) {
            Prefs.sp(app).edit().putBoolean(Prefs.K_LOCKED, true).apply(); restoreUnlock = true
        }

        val tk = Any()
        token = tk
        macroName = name; totalMs = macro.totalMs; elapsedMs = 0; sent = 0; rejected = 0
        state = State.PLAYING                          // cerrojo: ya no se admite otro inicio
        baseUptime = SystemClock.uptimeMillis() + MacroPrefs.delayMs(app)
        val lead = MacroPrefs.leadMs(app).toLong()
        lastMessage = "Reproduciendo (inicio: $source)"
        postTicker(tk)
        scheduleHold(svc, macro, 0, tk, lead)
        handler.postAtTime({ if (token === tk) finish("Macro completada") }, tk, baseUptime + macro.totalMs + 500)
        showNotification(app)
        changed()
        return true
    }

    fun stop(reason: String) {
        if (state == State.PLAYING) finish("Detenida: $reason")
    }

    private fun finish(msg: String) {
        val old = token
        token = Any()                                  // invalida cualquier cadena de pulsación en vuelo
        handler.removeCallbacksAndMessages(old)
        state = State.IDLE
        holdActive = false
        lastMessage = msg
        appCtx?.let { app ->
            app.getSystemService(NotificationManager::class.java).cancel(NOTIF)
            if (restoreUnlock) { Prefs.sp(app).edit().putBoolean(Prefs.K_LOCKED, false).apply(); restoreUnlock = false }
        }
        changed()
    }

    private fun postTicker(tk: Any) {
        handler.postAtTime({
            if (token !== tk) return@postAtTime
            elapsedMs = (SystemClock.uptimeMillis() - baseUptime).coerceIn(0L, totalMs)
            changed()
            postTicker(tk)
        }, tk, SystemClock.uptimeMillis() + 250)
    }

    // Encadena las pulsaciones sobre una línea de tiempo absoluta (sin acumular deriva).
    private fun scheduleHold(svc: AccessibilityService, m: Macro, i: Int, tk: Any, lead: Long) {
        if (i >= m.holds.size) return
        val h = m.holds[i]
        val at = maxOf(baseUptime + h.startMs - lead, SystemClock.uptimeMillis())
        handler.postAtTime({
            if (token !== tk) return@postAtTime
            holdStep(svc, Path().apply { moveTo(px, py) }, h.durMs, null, tk)
            holdActive = true; changed()
            handler.postAtTime({ if (token === tk) { holdActive = false; changed() } }, tk, SystemClock.uptimeMillis() + h.durMs)
            scheduleHold(svc, m, i + 1, tk, lead)
        }, tk, at)
    }

    // Una pulsación larga se emite en trozos de 200 ms con el dedo "abajo" para poder soltarla al detener.
    private fun holdStep(
        svc: AccessibilityService, p: Path, remaining: Long,
        prev: GestureDescription.StrokeDescription?, tk: Any
    ) {
        val cancelled = token !== tk
        if (cancelled && prev == null) return
        val chunk = if (cancelled) 1L else minOf(remaining, CHUNK_MS)
        val rest = if (cancelled) 0L else remaining - chunk
        val willContinue = rest > 0
        val stroke = try {
            prev?.continueStroke(p, 0L, chunk, willContinue)
                ?: GestureDescription.StrokeDescription(p, 0L, chunk, willContinue)
        } catch (e: Exception) { rejected++; return }
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val ok = svc.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                if (willContinue) holdStep(svc, p, rest, stroke, tk)
            }
        }, handler)
        if (ok) sent++ else rejected++
    }

    private fun showNotification(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Macros", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getBroadcast(
            ctx, 21, Intent(ctx, MacroStopReceiver::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        nm.notify(
            NOTIF,
            NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Reproduciendo macro")
                .setContentText(macroName)
                .setOngoing(true)
                .addAction(0, "Detener", stop)
                .build()
        )
    }
}
