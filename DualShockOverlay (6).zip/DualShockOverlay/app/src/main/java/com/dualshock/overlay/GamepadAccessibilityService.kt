package com.dualshock.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.dualshock.overlay.macro.MacroKeys
import com.dualshock.overlay.macro.MacroPlayer

/**
 * - Observa los botones del mando para el overlay (siempre).
 * - Solo consume el botón de inicio/parada de macros cuando la macro está ARMADA.
 * - Realiza toques (dispatchGesture) únicamente al reproducir una macro.
 * No lee contenido de pantalla (canRetrieveWindowContent=false).
 */
class GamepadAccessibilityService : AccessibilityService() {

    companion object { @Volatile var instance: GamepadAccessibilityService? = null }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        MacroPlayer.stop("servicio de accesibilidad desactivado")
        instance = null
        return super.onUnbind(intent)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        GamepadRepo.onKey(event)                    // el overlay siempre ve la pulsación
        return MacroKeys.onKey(this, event)         // true solo para el botón reservado de la macro
    }

    fun canGestures(): Boolean = try {
        (serviceInfo.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_PERFORM_GESTURES) != 0
    } catch (e: Exception) { true }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
