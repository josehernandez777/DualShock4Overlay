package com.dualshock.overlay.macro

import android.content.Context
import android.view.KeyEvent
import com.dualshock.overlay.GamepadRepo

/**
 * Decide si una tecla del mando debe consumirse. Solo se consumen los botones de inicio/parada
 * cuando la macro está ARMADA; con la macro desarmada el servicio no toca ninguna tecla.
 * Se consume DOWN, las repeticiones y el UP correspondiente, para que el juego no vea la pulsación.
 */
object MacroKeys {
    private val swallowed = HashSet<Int>()

    fun onKey(ctx: Context, e: KeyEvent): Boolean {
        if (!GamepadRepo.isPadSource(e.source)) return false
        val k = e.keyCode
        if (e.action == KeyEvent.ACTION_UP) return swallowed.remove(k)
        if (e.action != KeyEvent.ACTION_DOWN) return false
        if (swallowed.contains(k)) return true                       // repetición de una pulsación ya consumida
        if (!MacroPrefs.armed(ctx)) return false
        val playing = MacroPlayer.state == MacroPlayer.State.PLAYING
        when {
            k == MacroPrefs.stopKey(ctx) && playing -> MacroPlayer.stop("botón de parada del mando")
            k == MacroPrefs.startKey(ctx) -> MacroPlayer.start(ctx, "botón del mando")
            else -> return false
        }
        swallowed.add(k)
        return true
    }
}
